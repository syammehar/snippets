﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Configuration;
using System.Reflection;
using WebApi.Models.Entities;

namespace WebApi.Models
{
    //DBCC CHECKIDENT ('Users', RESEED, 1000000);
    //script-migration init u1
    public partial class AppDbContext : DbContext
    {
        protected readonly IConfiguration _configuration;

        public AppDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<UserToken> UserTokens { get; set; }
        public virtual DbSet<UserRole> UserRoles { get; set; }
        public virtual DbSet<Property> Properties { get; set; }
        public virtual DbSet<PropertyReview> Reviews { get; set; }
        public virtual DbSet<CategoryModel> Categories { get; set; }
        public virtual DbSet<CityModel> Addresses { get; set; }
        public virtual DbSet<Booking> Bookings { get; set; }
        public virtual DbSet<Article> Articles { get; set; }
        public virtual DbSet<ArticleSection> ArticleSections { get; set; }
        public virtual DbSet<PropertyFavorite> PropertyFavorites { get; set; }
        public virtual DbSet<Contact> Contacts { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Project> Projects { get; set; }
        public virtual DbSet<ProjectFloorPlan> ProjectFloorPlans { get; set; }
        public virtual DbSet<ProjectPaymentPlan> ProjectPaymentPlans { get; set; }
        public virtual DbSet<FileModel> ProjectImages { get; set; }
        public virtual DbSet<PropertyAmenity> PropertyAmenities { get; set; }
        public virtual DbSet<Amenity> Amenities { get; set; }
        public virtual DbSet<StickerModel> Stickers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_configuration.GetConnectionString("MainDatabase"));
            }
            //optionsBuilder.LogTo(Console.WriteLine);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}


/*
INSERT INTO Property_Cities (Name, NameAr, NameKz, NameRu, NameCh, Active, CityCount)
VALUES
    (N'Abu Dhabi', N'اسم أبو ظبي', N'Абу-Даби', N'Абу-Даби', N'阿布扎比', 1, 0),
    (N'Dubai', N'دبي', N'Дубай', N'Дубай', N'迪拜', 1, 0),
    (N'Sharjah', N'الشارقة', N'Шарджа', N'Шарджа', N'莎尔哈', 1, 0);


INSERT INTO Property_Areas (Name, NameAr, NameKz, NameRu, NameCh, AreaCount, Active, CityId)
VALUES
    (N'Saadiyat Island', N'جزيرة السعديات', N'Саадият Айленд', N'Саадият Айленд', N'沙迪亚岛', 0, 1, 1),
    (N'Al Reem Island', N'جزيرة الريم', N'Аль Рим Айленд', N'Аль Рим Айленд', N'阿尔里姆岛', 0, 1, 1),
    (N'Al Raha', N'الراحة', N'Аль Раха', N'Аль Раха', N'阿尔拉哈', 0, 1, 1),
    (N'Abu Dhabi Corniche', N'كورنيش أبو ظبي', N'Абу-Даби Корниш', N'Абу-Даби Корниш', N'阿布扎比海滨大道', 0, 1, 1),
    (N'Al Reef', N'الريف', N'Аль Риф', N'Аль Риф', N'艾尔里夫', 0, 1, 1),
    (N'Khalidiya', N'الخالدية', N'Халидия', N'Халидия', N'哈利迪亚', 0, 1, 1),
    (N'Al Maryah Island', N'جزيرة المارية', N'Аль Марья Айленд', N'Аль Марья Айленд', N'阿尔玛里亚岛', 0, 1, 1),
    (N'Al Zahiyah', N'الزاهية', N'Аль Захия', N'Аль Захия', N'艾尔扎希亚', 0, 1, 1),
    (N'Al Markaziyah', N'المركزية', N'Аль Марказия', N'Аль Марказия', N'艾尔马卡兹尼亚', 0, 1, 1);
 
	INSERT INTO Property_Areas (Name, NameAr, NameKz, NameRu, NameCh, AreaCount, Active, CityId)
VALUES
    (N'Jumeirah Lake Towers', N'أبراج بحيرة جميرا', N'Жумейра Лейк Тауэрс', N'Джумейра Лейк Тауэрс', N'朱美拉湖塔', 0, 1, 2),
    (N'Jebel Ali', N'جبل علي', N'Жебель Али', N'Джебель Али', N'杰贝阿里', 0, 1, 2),
    (N'Palm Jumeirah', N'نخلة جميرا', N'Пальма Джумейра', N'Пальма Джумейра', N'棕榈岛', 0, 1, 2),
    (N'Deira', N'ديرة', N'Дейра', N'Дейра', N'迪拉', 0, 1, 2),
    (N'Jumeirah Village Circle (JVC)', N'دائرة جميرا للقرى', N'Жумейра Виллидж Сиркл (ДжВЦ)', N'Джумейра Вилладж Сиркл (ДжВЦ)', N'朱美拉村圈', 0, 1, 2),
    (N'Bur Dubai', N'بر دبي', N'Бур Дубай', N'Бур Дубай', N'布尔迪拜', 0, 1, 2),
    (N'Bluewaters Island', N'جزيرة بلووترز', N'Блувотерс Айленд', N'Блувотерс Айленд', N'蓝水岛', 0, 1, 2),
    (N'Jumeirah Beach Residence (JBR)', N'منطقة جميرا بيتش ريزيدنس', N'Жумейра Бич Резиденс', N'Джумейра Бич Резиденс', N'朱美拉海滩住宅区', 0, 1, 2),
    (N'Downtown', N'وسط المدينة', N'Даунтаун', N'Даунтаун', N'市中心', 0, 1, 2),
    (N'Business Bay', N'الخليج التجاري', N'Бизнес-Бей', N'Бизнес-Бей', N'商务湾', 0, 1, 2),
    (N'Dubai Marina', N'مرسى دبي', N'Дубай Марина', N'Дубай Марина', N'迪拜码头', 0, 1, 2);
 
	INSERT INTO Property_Areas (Name, NameAr, NameKz, NameRu, NameCh, AreaCount, Active, CityId)
VALUES
    (N'AL MAJAZ', N'المجاز', N'Аль Маджаз', N'Аль Маджаз', N'阿尔马加兹', 0, 1, 3),
    (N'AL KHAN', N'الخان', N'Аль Хан', N'Аль Хан', N'阿尔汗', 0, 1, 3),
    (N'AL NAHDA', N'النهدة', N'Аль Нахда', N'Аль Нахда', N'Аль Нахда', 0, 1, 3),
    (N'AL TAAWUN', N'التعاون', N'Аль Тааун', N'Аль Тааун', N'阿尔-Тааун', 0, 1, 3),
    (N'UNIVERSITY CITY', N'مدينة الجامعة', N'Университетский Город', N'Университетский Город', N'大学城', 0, 1, 3),
    (N'AL JAZZAT', N'الجزاة', N'Аль Джаззат', N'Аль Джаззат', N'Аль Джаззат', 0, 1, 3),
    (N'MUWAILIH', N'المويلح', N'Мувайлих', N'Мувайлих', N'Мувайлих', 0, 1, 3),
    (N'AL FALAJ', N'الفلاج', N'Аль Фалах', N'Аль Фалах', N'Аль Фалах', 0, 1, 3),
    (N'HALWAN', N'حلوان', N'Халван', N'Халван', N'Халван', 0, 1, 3);
 */