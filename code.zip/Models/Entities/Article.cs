﻿namespace WebApi.Models.Entities
{
    public class Article
    {
        public Article()
        {
            Sections = new HashSet<ArticleSection>();
        }
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? TitleAr { get; set; }
        public string? TitleCh { get; set; }
        public string? TitleRu { get; set; }
        public string? Slug { get; set; }
        public string? ImagePath { get; set; }
        public string? ImagePathFull { get; set; }
        public bool Active { get; set; }
        public bool IsBlog { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public ICollection<ArticleSection> Sections { get; set; }
    }

    public class ArticleSection
    {
        public int Id { get; set; }
        public int ArticleId { get; set; }
        public string? Title { get; set; }
        public string? TitleAr { get; set; }
        public string? TitleCh { get; set; }
        public string? TitleRu { get; set; }
        public string? Description { get; set; }
        public string? DescriptionAr { get; set; }
        public string? DescriptionCh { get; set; }
        public string? DescriptionRu { get; set; }
        public bool IsHtml { get; set; }
        public string? ImagePath { get; set; }
        public string? ImagePathFull { get; set; }
        public Article? Article { get; set; }
    }

}
