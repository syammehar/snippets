﻿namespace WebApi.Models.Entities
{
    public class PropertyFavorite
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int PropertyId { get; set; }
        public bool Active { get; set; }
        public Property? Property { get; set; }
        public User? User { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
