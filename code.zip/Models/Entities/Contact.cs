﻿namespace WebApi.Models.Entities
{
    public class Contact
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Message { get; set; }
        public int? PropertyId { get; set; }
        public int? ProjectId { get; set; }
        public string? ItemName { get; set; }
        public string? ContactType { get; set; }
        public bool Active { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public Property? Property { get; set; }
        public Project? Project { get; set; }

    }
}
