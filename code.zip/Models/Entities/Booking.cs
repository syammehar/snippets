﻿using System.Reflection;

namespace WebApi.Models.Entities
{
    public class Booking
    {
        public int Id { get; set; }
        public string? FullName { get; set; }
        public string? Gender { get; set; }
        public DateTime Date { get; set; }
        public string? Contact { get; set; }
        public string? Email { get; set; }
        public string? Country { get; set; }
        public string? NoteToAgent { get; set; }
        public bool Closed { get; set; }
        public int UserId { get; set; }
        public int AgentId { get; set; }
        public int PropertyId { get; set; }
        public Property? Property { get; set; }
        public User? User { get; set; }
        public User? Agent { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}