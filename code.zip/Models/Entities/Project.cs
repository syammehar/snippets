﻿namespace WebApi.Models.Entities
{
    public class Project
    {
        public Project()
        {
            Images = new HashSet<FileModel>();
            Amenities = new HashSet<ProjectAmenity>();
            Stickers2 = new HashSet<StickerModel>();
            FloorPlan = new HashSet<ProjectFloorPlan>();
            PaymentPlan = new HashSet<ProjectPaymentPlan>();
            Categories = new HashSet<ProjectCategory>();
        }
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? NameAr { get; set; }
        public string? DescriptionAr { get; set; }
        public string? NameRu { get; set; }
        public string? DescriptionRu { get; set; }
        public string? NameCh { get; set; }
        public string? DescriptionCh { get; set; }
        public string? Address { get; set; }
        public string? AddressAr { get; set; }
        public string? AddressRu { get; set; }
        public string? AddressCh { get; set; }
        public string? AboutLocation { get; set; }
        public string? AboutLocationAr { get; set; }
        public string? AboutLocationCh { get; set; }
        public string? AboutLocationRu { get; set; }
        public string? Slug { get; set; }
        public string? VideoUrl { get; set; }
        public decimal StartingPrice { get; set; }
        public string? Units { get; set; }
        public decimal Size { get; set; }
        public string? Handover { get; set; }
        public string? MapCoordinates { get; set; }
        public string? ImagePath { get; set; }
        public int CityId { get; set; }
        public int AreaId { get; set; }
        public bool Active { get; set; }
        public string? Stickers { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public CityModel? City { get; set; }
        public AreaModel? Area { get; set; }
        public ICollection<FileModel> Images { get; set; }
        public ICollection<ProjectCategory> Categories { get; set; }
        public ICollection<ProjectAmenity> Amenities { get; set; }
        public ICollection<StickerModel> Stickers2 { get; set; }
        public ICollection<ProjectFloorPlan> FloorPlan { get; set; }
        public ICollection<ProjectPaymentPlan> PaymentPlan { get; set; }

    }


    public class StickerModel 
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameCh { get; set; }
        public string? NameRu { get; set; }
        public Project? Project { get; set; }
    }

    public class ProjectCategory
    {
        public int ProjectId { get; set; }
        public Project? Project { get; set; }
        public int CategoryId { get; set; }
        public CategoryModel? Category { get; set; }
    }

    public class ProjectFloorPlan
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public int CategoryId { get; set; }
        public string? Type { get; set; }
        public string? TypeAr { get; set; }
        public string? TypeCh { get; set; }
        public string? TypeRu { get; set; }
        public string? UnitType { get; set; }
        public decimal Size { get; set; }
        public decimal? Price { get; set; }
        public string? ImagePath { get; set; }
        public string? ImagePathFull { get; set; }
        public Project? Project { get; set; }
        public CategoryModel? Category { get; set; }


    }

    public class ProjectPaymentPlan
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameCh { get; set; }
        public string? NameRu { get; set; }
        public string? Amount { get; set; }
        public Project? Project { get; set; }
    }

    public class FileModel
    {
        public int Id { get; set; }
        public int? ProjectId { get; set; }
        public Project? Project { get; set; }
        public int? PropertyId { get; set; }
        public Property? Property { get; set; }
        public string? FullPath { get; set; }
        public string? RelativePath { get; set; }
        public string? Name { get; set; }
        public string? MimeType { get; set; }
        public string? ImageType { get; set; }
        public string? SubType { get; set; }
        public bool Deleted { get; set; }
    }


    public enum HandOverQuarter
    {
        Q1 = 1,
        Q2 = 2,
        Q3 = 3,
        Q4 = 4,
    }
}
