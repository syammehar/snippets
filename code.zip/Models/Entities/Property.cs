﻿namespace WebApi.Models.Entities
{
    public class Property
    {
        public Property()
        {
            Images = new HashSet<FileModel>();
            Reviews = new HashSet<PropertyReview>();
            Amenities = new HashSet<PropertyAmenity>();
        }
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? NameAr { get; set; }
        public string? DescriptionAr { get; set; }
        public string? NameRu { get; set; }
        public string? DescriptionRu { get; set; }
        public string? NameCh { get; set; }
        public string? DescriptionCh { get; set; }
        public string? Address { get; set; }
        public string? AddressAr { get; set; }
        public string? AddressRu { get; set; }
        public string? AddressCh { get; set; }
        public string? Slug { get; set; }
        public string? VideoUrl { get; set; }
        public int Bedroom { get; set; }
        public int Bathroom { get; set; }
        public int Floor { get; set; }
        public int TotalFloor { get; set; }
        public decimal? Size { get; set; }
        public string? MapCoordinates { get; set; }
        public decimal Price { get; set; }
        public bool Active { get; set; }
        public int CategoryId { get; set; } 
        public int CityId { get; set; } 
        public int AreaId { get; set; } 
        public int AgentId { get; set; } 
        public bool IsRental { get; set; } 
        public bool IsStudio { get; set; } 
        public decimal RentPerMonth { get; set; } 
        public decimal RentPerDay { get; set; }
        public bool BestOffer { get; set; }
        public int Stars1 { get; set; }
        public int Stars2 { get; set; }
        public int Stars3 { get; set; }
        public int Stars4 { get; set; }
        public int Stars5 { get; set; }
        public string? ImagePath { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public CategoryModel? Category { get; set; }
        public CityModel? City { get; set; }
        public AreaModel? Area { get; set; }
        public User? User { get; set; }
        public ICollection<PropertyReview> Reviews { get; set; }
        public ICollection<FileModel> Images { get; set; }
        public ICollection<PropertyAmenity> Amenities { get; set; }
    }

    public class CategoryModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; } 
        public string? NameCh { get; set; }
        public string? IconPath { get; set; }
        public int PropertyCount { get; set; }
    }

    public class PropertyReview
    {
        public int Id { get; set; }
        public int PropertyId { get; set; }
        public int UserId { get; set; }
        public int Stars { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public User? User { get; set; }
        public Property? Property { get; set; }

    }


    public class Amenity
    {
        public int Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; }
        public string? NameCh { get; set; }
    }


    public class PropertyAmenity
    {
        public int AmenityId { get; set; }
        public Amenity? Amenity { get; set; }
        public int PropertyId { get; set; }
        public Property? Property { get; set; }

    }
    
    public class ProjectAmenity
    {
        public int AmenityId { get; set; }
        public Amenity? Amenity { get; set; }
        public int ProjectId { get; set; }
        public Project? Project { get; set; }

    }

    //public class PropertyImage
    //{
    //    public int Id { get; set; }
    //    public int PropertyId { get; set; }
    //    public Property? Property { get; set; }
    //    public string? FullPath { get; set; }
    //    public string? RelativePath { get; set; }
    //    public string? Name { get; set; }
    //    public string? MimeType { get; set; }
    //}

    
    public class CityModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; }
        public string? NameCh { get; set; }
        public int CityCount { get; set; }
        public bool Active { get; set; }
    }
    public class AreaModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; }
        public string? NameCh { get; set; }
        public int AreaCount { get; set; }
        public bool Active { get; set; }
        public int CityId { get; set; }
        public CityModel? City { get; set; }
    }


    public class Testimonial
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Title { get; set; }
        public string? Comments { get; set; }
        public string? ProfilePhoto { get; set; }
        public int Star { get; set; }
        public bool Active { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}