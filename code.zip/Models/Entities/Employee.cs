﻿namespace WebApi.Models.Entities
{
    public class Employee
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Position { get; set; }
        public string? ProfilePhoto { get; set; }
        public string? Description { get; set; }
        public string? DescriptionAr { get; set; }
        public string? DescriptionCh { get; set; }
        public string? DescriptionRu { get; set; }
        public string? PhoneNubmer { get; set; }
        public string? Whatsapp { get; set; }
        public string? Facebook { get; set; }
        public string? Instagram { get; set; }
        public string? TikTok { get; set; }
        public string? Linkedin { get; set; }
        public string? Twitter { get; set; }
        public bool Active { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
