﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WebApi.Models.Entities;

namespace WebApi.Models.Configurations
{
    public class ProjectConfiguration : IEntityTypeConfiguration<Project>
    {
        public void Configure(EntityTypeBuilder<Project> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Description).HasMaxLength(4000);
            entity.Property(e => e.Address).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.DescriptionAr).HasMaxLength(4000);
            entity.Property(e => e.AddressAr).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.DescriptionRu).HasMaxLength(4000);
            entity.Property(e => e.AddressRu).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.Property(e => e.DescriptionCh).HasMaxLength(4000);
            entity.Property(e => e.AddressCh).HasMaxLength(100);
            entity.Property(e => e.AboutLocation).HasMaxLength(4000);
            entity.Property(e => e.AboutLocationAr).HasMaxLength(4000);
            entity.Property(e => e.AboutLocationCh).HasMaxLength(4000);
            entity.Property(e => e.AboutLocationRu).HasMaxLength(4000);
            entity.Property(e => e.Units).HasMaxLength(100);
            entity.Property(e => e.MapCoordinates).HasMaxLength(100);
            entity.Property(e => e.Slug).HasMaxLength(200);
            entity.Property(e => e.VideoUrl).HasMaxLength(200);
            entity.Property(e => e.ImagePath).HasMaxLength(300);
            entity.Property(e => e.Stickers).HasMaxLength(300);
            entity.Property(e => e.Handover).HasMaxLength(100);

            //entity.HasOne(x => x.Category).WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(x => x.City).WithMany().HasForeignKey(x => x.CityId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.UpdatedDate);

        }
    }

    public class ProjectFloorPlanConfiguration : IEntityTypeConfiguration<ProjectFloorPlan>
    {
        public void Configure(EntityTypeBuilder<ProjectFloorPlan> entity)
        {
            entity.Property(e => e.Type).HasMaxLength(100);
            entity.Property(e => e.TypeAr).HasMaxLength(100);
            entity.Property(e => e.TypeCh).HasMaxLength(100);
            entity.Property(e => e.TypeRu).HasMaxLength(100);
            entity.Property(e => e.UnitType).HasMaxLength(100);
            entity.Property(e => e.Price).HasMaxLength(20);
            entity.Property(e => e.ImagePath).HasMaxLength(300);
            entity.Property(e => e.ImagePathFull).HasMaxLength(300);
            entity.ToTable("Project_Floor_Plans");
        }
    }

    public class ProjectPaymentPlanConfiguration : IEntityTypeConfiguration<ProjectPaymentPlan>
    {
        public void Configure(EntityTypeBuilder<ProjectPaymentPlan> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.Amount).HasMaxLength(100);
            entity.ToTable("Project_Payment_Plans");
        }
    }

    public class ProjectImageConfiguration : IEntityTypeConfiguration<FileModel>
    {
        public void Configure(EntityTypeBuilder<FileModel> entity)
        {
            entity.Property(e => e.FullPath).HasMaxLength(300);
            entity.Property(e => e.RelativePath).HasMaxLength(300);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.MimeType).HasMaxLength(100);
            entity.Property(e => e.ImageType).HasMaxLength(100);
            entity.Property(e => e.SubType).HasMaxLength(100);
            entity.ToTable("Images");
        }
    }
    public class ProjectCategoryConfiguration : IEntityTypeConfiguration<ProjectCategory>
    {
        public void Configure(EntityTypeBuilder<ProjectCategory> entity)
        {
            entity.HasKey(e => new { e.CategoryId, e.ProjectId });
            entity.ToTable("Project_Categories");

        }
    }

    public class ProjectStickerConfiguration : IEntityTypeConfiguration<StickerModel>
    {
        public void Configure(EntityTypeBuilder<StickerModel> entity)
        {

            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.ToTable("Project_Stickers");

        }
    }
}