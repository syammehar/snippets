﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WebApi.Models.Entities;

namespace WebApi.Models.Configurations
{
    public class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> entity) 
        {
            entity.Property(e=>e.FirstName).HasMaxLength(100);
            entity.Property(e=>e.LastName).HasMaxLength(100);
            entity.Property(e=>e.Position).HasMaxLength(100);
            entity.Property(e=>e.ProfilePhoto).HasMaxLength(200);
            entity.Property(e=>e.Description).HasMaxLength(1000);
            entity.Property(e=>e.DescriptionAr).HasMaxLength(1000);
            entity.Property(e=>e.DescriptionCh).HasMaxLength(1000);
            entity.Property(e=>e.DescriptionRu).HasMaxLength(1000);
            entity.Property(e=>e.PhoneNubmer).HasMaxLength(100);
            entity.Property(e=>e.Instagram).HasMaxLength(100);
            entity.Property(e=>e.Linkedin).HasMaxLength(100);
            entity.Property(e=>e.Twitter).HasMaxLength(100);
            entity.Property(e=>e.TikTok).HasMaxLength(100);
            entity.Property(e=>e.Facebook).HasMaxLength(100);
            entity.Property(e=>e.Whatsapp).HasMaxLength(100);
        }
    }
}
