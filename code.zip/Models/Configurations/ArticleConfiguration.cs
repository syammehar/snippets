﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WebApi.Models.Entities;

namespace WebApi.Models.Configurations
{
    public class ArticleConfiguration : IEntityTypeConfiguration<Article>
    {
        public void Configure(EntityTypeBuilder<Article> entity)
        {
            entity.Property(e => e.Title).HasMaxLength(300);
            entity.Property(e => e.TitleAr).HasMaxLength(300);
            entity.Property(e => e.TitleCh).HasMaxLength(300);
            entity.Property(e => e.TitleRu).HasMaxLength(300);
            entity.Property(e => e.Slug).HasMaxLength(300);
            entity.Property(e => e.ImagePath).HasMaxLength(500);
            entity.Property(e => e.ImagePathFull).HasMaxLength(500);

        }       
    }

    public class ArticleSectionConfiguration : IEntityTypeConfiguration<ArticleSection>
    {
        public void Configure(EntityTypeBuilder<ArticleSection> entity)
        {
            entity.Property(e => e.Title).HasMaxLength(500);
            entity.Property(e => e.TitleAr).HasMaxLength(500);
            entity.Property(e => e.TitleCh).HasMaxLength(500);
            entity.Property(e => e.TitleRu).HasMaxLength(500);
            entity.Property(e => e.Description).HasMaxLength(4000);
            entity.Property(e => e.DescriptionAr).HasMaxLength(4000);
            entity.Property(e => e.DescriptionCh).HasMaxLength(4000);
            entity.Property(e => e.DescriptionRu).HasMaxLength(4000);
            entity.Property(e => e.ImagePath).HasMaxLength(500);
            entity.Property(e => e.ImagePathFull).HasMaxLength(500);

            entity.ToTable("Article_Sections");

        }
    }
}
