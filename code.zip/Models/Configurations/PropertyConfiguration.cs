﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using WebApi.Models.Entities;

namespace WebApi.Models.Configurations
{
    public class PropertyConfiguration : IEntityTypeConfiguration<Property>
    {
        public void Configure(EntityTypeBuilder<Property> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Description).HasMaxLength(4000);
            entity.Property(e => e.Address).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.DescriptionAr).HasMaxLength(4000);
            entity.Property(e => e.AddressAr).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.DescriptionRu).HasMaxLength(4000);
            entity.Property(e => e.AddressRu).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.Property(e => e.DescriptionCh).HasMaxLength(4000);
            entity.Property(e => e.AddressCh).HasMaxLength(100);
            entity.Property(e => e.MapCoordinates).HasMaxLength(100);
            entity.Property(e => e.Slug).HasMaxLength(200);
            entity.Property(e => e.VideoUrl).HasMaxLength(200);
            entity.Property(e => e.ImagePath).HasMaxLength(300);

            entity.HasOne(x => x.User).WithMany().HasForeignKey(x => x.AgentId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(x => x.Category).WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(x => x.City).WithMany().HasForeignKey(x => x.CityId).OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.UpdatedDate);
        }
    }
    public class PropertyReviewConfiguration : IEntityTypeConfiguration<PropertyReview>
    {
        public void Configure(EntityTypeBuilder<PropertyReview> entity)
        {
            entity.Property(e => e.Comment).HasMaxLength(500);
            entity.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);

            entity.ToTable("Property_Reviews");
        }
    }
    //public class PropertyImageConfiguration : IEntityTypeConfiguration<PropertyImage>
    //{
    //    public void Configure(EntityTypeBuilder<PropertyImage> entity)
    //    {
    //        entity.Property(e => e.FullPath).HasMaxLength(300);
    //        entity.Property(e => e.RelativePath).HasMaxLength(300);
    //        entity.Property(e => e.Name).HasMaxLength(100);
    //        entity.Property(e => e.MimeType).HasMaxLength(100);
    //        entity.ToTable("Property_Images");
    //    }
    //}
    public class PropertyCategoryConfiguration : IEntityTypeConfiguration<CategoryModel>
    {
        public void Configure(EntityTypeBuilder<CategoryModel> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(30);
            entity.Property(e => e.NameRu).HasMaxLength(30);
            entity.Property(e => e.NameCh).HasMaxLength(30);
            entity.Property(e => e.IconPath).HasMaxLength(300);
            entity.ToTable("Categories");
        }
    }
    public class PropertyFavoriteConfiguration : IEntityTypeConfiguration<PropertyFavorite>
    {
        public void Configure(EntityTypeBuilder<PropertyFavorite> entity)
        {
            entity.ToTable("Property_Favorites");
        }
    }

    public class PropertyCityConfiguration : IEntityTypeConfiguration<CityModel>
    {
        public void Configure(EntityTypeBuilder<CityModel> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.ToTable("Cities");
        }
    }
    public class PropertyAreaConfiguration : IEntityTypeConfiguration<AreaModel>
    {
        public void Configure(EntityTypeBuilder<AreaModel> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.ToTable("Areas");
        }
    }

    public class TestimonialConfiguration : IEntityTypeConfiguration<Testimonial>
    {
        public void Configure(EntityTypeBuilder<Testimonial> entity)
        {
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Title).HasMaxLength(150);
            entity.Property(e => e.Comments).HasMaxLength(600);
            entity.Property(e => e.ProfilePhoto).HasMaxLength(200);
        }
    }

    public class AmenityConfiguration : IEntityTypeConfiguration<Amenity>
    {
        public void Configure(EntityTypeBuilder<Amenity> entity)
        {
            entity.Property(e => e.Code).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.NameAr).HasMaxLength(100);
            entity.Property(e => e.NameRu).HasMaxLength(100);
            entity.Property(e => e.NameCh).HasMaxLength(100);
            entity.ToTable("Amenities");

        }
    }
    public class PropertyAmenityConfiguration : IEntityTypeConfiguration<PropertyAmenity>
    {
        public void Configure(EntityTypeBuilder<PropertyAmenity> entity)
        {
            entity.HasKey(e => new { e.AmenityId, e.PropertyId });
            entity.ToTable("Property_Amenities");

            //entity.HasOne(x => x.Property)
            //.WithMany(x => x.Amenities)
            //.HasForeignKey(x => x.PropertyId)
            //.OnDelete(DeleteBehavior.Restrict);

        }
    }
    public class ProjectAmenityConfiguration : IEntityTypeConfiguration<ProjectAmenity>
    {
        public void Configure(EntityTypeBuilder<ProjectAmenity> entity)
        {
            entity.HasKey(e => new { e.AmenityId, e.ProjectId });
            entity.ToTable("Project_Amenities");

            //entity.HasOne(x => x.Property)
            //.WithMany(x => x.Amenities)
            //.HasForeignKey(x => x.PropertyId)
            //.OnDelete(DeleteBehavior.Restrict);

        }
    }
}
