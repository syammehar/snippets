﻿using WebApi.Common;
using WebApi.Common.Exceptions;
using WebApi.Common.Models;
using WebApi.Controllers;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;
using static System.Net.Mime.MediaTypeNames;

namespace WebApi.Services
{
    public class EmployeeService
    {
        private readonly UnitOfWork _uow;
        private readonly UploadService _upload;
        private readonly TokenService _tokenService;

        public EmployeeService(UnitOfWork uow,
            UploadService upload,
            TokenService tokenService)
        {
            _uow = uow;
            _upload = upload;
            _tokenService = tokenService;
        }

        public async Task<Employee> Save(EmployeeVm employee)
        {
            var existing = employee.Id.HasValue && employee.Id > 0 ? await _uow.Employees.GetDetails(employee.Id.Value) : null;

            var newEmp = Map(employee, existing ?? new Employee());
            if (existing is null)
            {
                newEmp.CreatedDate = newEmp.UpdatedDate;
                newEmp.Active = true;

                newEmp = await _uow.Employees.Add(newEmp);
            }

            await _uow.CompleteAsync();

            return newEmp;
        }
        public async Task<DataPageModel<EmployeeVm>> Filter(EmployeeFilter filter)
        {
            var data = await _uow.Employees.Filter(filter);

            return new DataPageModel<EmployeeVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new EmployeeVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };


        }

        private Employee Map(EmployeeVm employee, Employee existing)
        {
            var curTime = DateTime.UtcNow;

            existing.FirstName = employee.FirstName;
            existing.LastName = employee.LastName;
            existing.Position = employee.Position;
            existing.Description = employee.Description;
            existing.DescriptionAr = employee.DescriptionAr;
            existing.DescriptionCh = employee.DescriptionCh;
            existing.DescriptionRu = employee.DescriptionRu;
            existing.PhoneNubmer = employee.PhoneNubmer;
            existing.Instagram = employee.Instagram;
            existing.Twitter = employee.Twitter;
            existing.TikTok = employee.TikTok;
            existing.Facebook = employee.Facebook;
            existing.Linkedin = employee.Linkedin;
            existing.Whatsapp = employee.Whatsapp;
            existing.UpdatedDate = curTime;

            var tempImg = employee.Images.FirstOrDefault();
            if (tempImg is not null && !string.IsNullOrEmpty(tempImg.Token))
            {
                existing.ProfilePhoto = _tokenService.ParseToken<FileToken>(tempImg.Token)?.FullPath;
            }
            return existing;
        }

        private EmployeeVm Map(Employee source, EmployeeVm dest)
        {
            dest.Id = source.Id;
            dest.FirstName = source.FirstName;
            dest.LastName = source.LastName;
            dest.Position = source.Position;
            dest.Description = source.Description;
            dest.DescriptionAr = source.DescriptionAr;
            dest.DescriptionCh = source.DescriptionCh;
            dest.DescriptionRu = source.DescriptionRu;
            dest.PhoneNubmer = source.PhoneNubmer;
            dest.Instagram = source.Instagram;
            dest.Twitter = source.Twitter;
            dest.TikTok = source.TikTok;
            dest.Facebook = source.Facebook;
            dest.Linkedin = source.Linkedin;
            dest.Whatsapp = source.Whatsapp;
            dest.ProfilePhoto = source.ProfilePhoto;

            if (source.ProfilePhoto != null)
            {
                var token = _tokenService.CreateToken(new FileModel
                {
                    MimeType = source.ProfilePhoto,
                    Name = source.ProfilePhoto,
                    FullPath = source.ProfilePhoto,
                });

                dest.ProfilePhotoToken = token; 
            }

            dest.Active = source.Active;
            dest.CreatedDate = source.CreatedDate;
            dest.UpdatedDate = source.UpdatedDate;

            return dest;
        }

        internal async Task<EmployeeVm> ChangeEmployeeStatus(int id, bool active)
        {
            var status = await _uow.Employees.FindOne(x => x.Id == id)
                ?? throw new AppBadRequestException($"Employee with id:{id} for logged in user not found."); ;

            var curTime = DateTime.UtcNow;

            if (status.Active != active)
            {

                status.Active = active;
                status.UpdatedDate = curTime;
                await _uow.CompleteAsync();

            }

            return Map(status, new EmployeeVm());
        }

        internal async Task<EmployeeVm> GetDetails(int id)
        {
            var employee = await _uow.Employees.GetDetails(id);

            return employee is null
                ? throw new Exception($"Employee with Id:{id} not found")
                : Map(employee, new EmployeeVm());
        }
    }
}