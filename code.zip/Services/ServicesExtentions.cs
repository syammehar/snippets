﻿namespace WebApi.Services
{
    public static class ServicesExtension
    {
        public static IServiceCollection AddBusinessServices(this IServiceCollection services)
        {
            //Business Services
            services.AddScoped<PropertyService>();
            services.AddScoped<ArticleService>();
            services.AddScoped<ReviewsService>();
            services.AddScoped<TestimonialService>();
            services.AddScoped<ContactService>();
            services.AddScoped<EmployeeService>();
            services.AddScoped<ProjectService>();
            return services;
        }
    }
}
