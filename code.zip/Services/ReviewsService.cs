﻿using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.ViewModels;

namespace WebApi.Services
{
    public class ReviewsService
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly UploadService _upload;

        public ReviewsService(LoggedInUser user, 
            UnitOfWork uow, 
            UploadService upload)
        {
            _user = user;
            _uow = uow;
            _upload = upload;
        }

        public async Task<PropertyReview> Save(PropertyReview review)
        {
            var property = await _uow.Properties.Find(review.PropertyId);
            if (property is null)
            {
                throw new Exception($"Property with id: '{review.PropertyId}'not found");
            }

            if (review.Stars == 5) property.Stars5++;
            else if (review.Stars == 4) property.Stars4++;
            else if (review.Stars == 3) property.Stars3++;
            else if (review.Stars == 2) property.Stars2++;
            else if (review.Stars == 1) property.Stars1++;

            var curTime = DateTime.UtcNow;
            review.CreatedDate = curTime;
            review.UpdatedDate = curTime;
            review.UserId = _user.UserId;

            review = await _uow.PropertyReviews.Add(review);
            await _uow.CompleteAsync();
            return review;
        }

        internal async Task<IEnumerable<ReviewVm>> GetByProperty(int propertyId)
        {
            var reviews = await _uow.PropertyReviews
             .ByPropertyId(propertyId);
            return reviews.Select(Map);
        }

        private ReviewVm Map(PropertyReview source)
        {
            var user = source.User is not null ? new UserVm
            {
                Id = source.User.Id,
                FirstName = source.User.FirstName,
                LastName = source.User.LastName,
                ProfilePhoto = source.User.ProfilePhoto,
            } : null;
            return new ReviewVm
            {
                Comment = source.Comment,
                CreatedDate = source.CreatedDate,
                UpdatedDate = source.UpdatedDate,
                PropertyId = source.PropertyId,
                Stars = source.Stars,
                UserId = source.UserId,
                Id = source.Id,
                User = user
            };
        }
    }
}
