﻿using WebApi.Common;
using WebApi.Common.Exceptions;
using WebApi.Common.Models;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Services
{
    public class ArticleService
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly TokenService _tokenService;
        private readonly UploadService _upload;

        public ArticleService(UnitOfWork uow,
            LoggedInUser user,
            TokenService tokenService,
            UploadService upload)
        {
            _uow = uow;
            _user = user;
            _tokenService = tokenService;
            _upload = upload;
        }

        public async Task<Article> Save(ArticleVm article)
        {
            var existing = article.Id.HasValue && article.Id > 0 ? await _uow.Articles.GetDetails(article.Id.Value) : null;

            var artNew = Map(article, existing ?? new Article());
            if (existing is null)
            {
                artNew.Slug = Utilities.CreateSlug(artNew.Title ?? "");
                artNew.Active = true;
                artNew.CreatedDate = artNew.UpdatedDate;
                artNew = await _uow.Articles.Add(artNew);
            }

            await _uow.CompleteAsync();

            return artNew;
        }

        internal async Task<ArticleVm> GetArtical(string slug)
        {
            var artId = Utilities.GetIdFromSlug(slug);
            var article = await _uow.Articles.GetDetails(artId);

            return article is null
                ? throw new Exception($"Article with Id:{artId} not found")
                : Map(article, new ArticleVm());
        }
        public async Task<DataPageModel<ArticleVm>> Filter(ArticleFilter filter)
        {
            var data = await _uow.Articles.Filter(filter);

            return new DataPageModel<ArticleVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new ArticleVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };
        }

        internal async Task<ArticleVm> ChangeArticleStatus(int id, bool active)
        {
            var status = await _uow.Articles.FindOne(x => x.Id == id)
                ?? throw new AppBadRequestException($"Artile or Blogs with id:{id} for logged in user not found."); ;

            var curTime = DateTime.UtcNow;

            if (status.Active != active)
            {

                status.Active = active;
                status.UpdatedDate = curTime;
                await _uow.CompleteAsync();

            }

            return Map(status, new ArticleVm());
        }

        private Article Map(ArticleVm article, Article existing)
        {
            var curTime = DateTime.UtcNow;

            existing.Title = article.Title;
            existing.TitleAr = article.TitleAr;
            existing.TitleCh = article.TitleCh;
            existing.TitleRu = article.TitleRu;
            existing.IsBlog = article.IsBlog;
            existing.UpdatedDate = curTime;

            var coverImg = _tokenService.ParseToken<FileToken>(article.ImageToken ?? "");
            existing.ImagePath = coverImg?.RelativePath;
            existing.ImagePathFull = coverImg?.FullPath;

            existing.Sections.Clear();
            foreach (var artSec in article.Sections)
            {
                var img = !string.IsNullOrEmpty(artSec.ImageToken)
                    ? _tokenService.ParseToken<FileToken>(artSec.ImageToken)
                    : null;
                existing.Sections.Add(new ArticleSection
                {
                    Description = artSec.Description,
                    DescriptionAr = artSec.DescriptionAr,
                    DescriptionCh = artSec.DescriptionCh,
                    DescriptionRu = artSec.DescriptionRu,
                    Title = artSec.Title,
                    TitleAr = artSec.TitleAr,
                    TitleCh = artSec.TitleCh,
                    TitleRu = artSec.TitleRu,
                    ImagePathFull = img?.FullPath,
                    ImagePath = img?.RelativePath,
                });
            }

            return existing;
        }

        private ArticleVm Map(Article source, ArticleVm dest)
        {
            dest.Id = source.Id;
            dest.Title = GetTranslatedValue(nameof(source.Title), source, source.Title);

            dest.TitleAr = source.TitleAr;
            dest.TitleCh = source.TitleCh;
            dest.TitleRu = source.TitleRu;
            dest.IsBlog = source.IsBlog;
            dest.Active = source.Active;
            dest.Slug = source.Slug + "-" + source.Id.ToString();
            dest.ImagePath = source.ImagePath;
            dest.ImagePathFull = source.ImagePathFull;
            dest.UpdatedDate = source.UpdatedDate;
            dest.CreatedDate = source.CreatedDate;
            dest.Sections = source.Sections.Select(x => Map(x));

            if (!string.IsNullOrEmpty(source.ImagePath))
            {
                var token = _tokenService.CreateToken(new FileModel
                {
                    FullPath = source.ImagePathFull,
                    RelativePath = source.ImagePath,
                });

                dest.ImageToken = token;
            }

            return dest;
        }
        private ArticleSectionVm Map(ArticleSection source)
        {
            var token = string.IsNullOrEmpty(source.ImagePath)
                ? null
                : _tokenService.CreateToken(new FileModel
                {
                    FullPath = source.ImagePathFull,
                    RelativePath = source.ImagePath,
                });
            return new ArticleSectionVm
            {
                Id = source.Id,
                ArticleId = source.ArticleId,
                Title = GetTranslatedValue(nameof(source.Title), source, source.Title),
                TitleAr = source.TitleAr,
                TitleCh = source.TitleCh,
                TitleRu = source.TitleRu,
                Description = GetTranslatedValue(nameof(source.Description), source, source.Description),
                DescriptionAr = source.DescriptionAr,
                DescriptionCh = source.DescriptionCh,
                DescriptionRu = source.DescriptionRu,
                IsHtml = source.IsHtml,
                ImagePath = source.ImagePath,
                ImagePathFull = source.ImagePathFull,
                ImageToken = token,
            };
        }
        private string? GetTranslatedValue<T>(string propName, T source, string? defaultValue)
        {
            if (string.IsNullOrEmpty(_user.LangPropertySuffix))
            {
                return defaultValue;
            }
            var type = typeof(T);
            var property = type.GetProperty(propName + _user.LangPropertySuffix);
            if (property is not null)
            {
                return property.GetValue(source)?.ToString();
            }
            return defaultValue;
        }
    }
}