﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Numerics;
using WebApi.Common;
using WebApi.Common.Exceptions;
using WebApi.Common.Models;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Persistence.Repository;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Services
{
    public class ProjectService
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly TokenService _tokenService;
        public ProjectService(
            UnitOfWork uow,
            LoggedInUser user,
            TokenService tokenService)
        {
            _uow = uow;
            _user = user;
            _tokenService = tokenService;
        }

        internal async Task<Project> Save(ProjectVm project)
        {

            var existing = project.Id.HasValue && project.Id > 0 ? await _uow.Projects.GetDetails(project.Id.Value) : null;

            var projNew = Map(project, existing ?? new Project());
            projNew.Slug = Utilities.CreateSlug(project.Name ?? "");
            if (existing is null)
            {
                projNew.CreatedDate = projNew.UpdatedDate;
                projNew.Active = true;

                //var category = await _uow.PropertyCategories.Find(project.CategoryId);
                //if (category != null)
                //{
                //    category.PropertyCount++;
                //}
                var area = await _uow.PropertyAreas.Find(project.AreaId);
                if (area != null)
                {
                    area.AreaCount++;
                }
                var city = await _uow.PropertyCities.Find(project.CityId);
                if (city != null)
                {
                    city.CityCount++;
                }

                projNew = await _uow.Projects.Add(projNew);
            }

            await _uow.CompleteAsync();

            //await ImgProcessing(project.Images);

            return projNew;
        }
        internal async Task<DataPageModel<ProjectVm>> Filter(ProjectFilter filter)
        {
            var data = await _uow.Projects.Filter(filter);

            return new DataPageModel<ProjectVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new ProjectVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };
        }
        internal async Task<ProjectVm> GetProject(string slug)
        {
            var projId = Utilities.GetIdFromSlug(slug);
            var project = await _uow.Projects.GetDetails(projId);

            return project is null
                ? throw new Exception($"Project with Id:{projId} not found")
                : Map(project, new ProjectVm());
        }
        internal async Task<ProjectVm> SaveFloorPlan(int projId, IEnumerable<FloorPlanVm> floorPlan)
        {
            var project = await _uow.Projects.GetDetails(projId) ?? throw new Exception($"Project with Id:{projId} not found");

            var newFloorPlan = floorPlan.Select(x => Map(x, projId));

            await _uow.ProjectFloorPlans.RemoveByProjectId(projId);
            await _uow.ProjectFloorPlans.AddRange(newFloorPlan);

            await _uow.CompleteAsync();

            return new ProjectVm { Id = project.Id, };
        }
        internal async Task<IEnumerable<FloorPlanVm>> GetFloorPlan(int pId)
        {
            var floorplan = await _uow.ProjectFloorPlans
             .ByProjectId(pId);
            return floorplan.Select(Map);
        }
        internal async Task<ProjectVm> ChangeProjectStatus(int id, bool active)
        {
            var project = await _uow.Projects.FindOne(x => x.Id == id)
                ?? throw new AppBadRequestException($"Project with id:{id} for logged in user not found.");

            if (project.Active != active)
            {
                project.Active = active;
                //var category = await _uow.PropertyCategories.Find(project.CategoryId);
                //if (category != null)
                //{
                //    if (project.Active)
                //        category.PropertyCount++;
                //    if (!project.Active)
                //        category.PropertyCount--;
                //}
                var area = await _uow.PropertyAreas.Find(project.AreaId);
                if (area != null)
                {
                    area.AreaCount = active ? area.AreaCount + 1 : area.AreaCount - 1;
                }
                var city = await _uow.PropertyCities.Find(project.CityId);
                if (city != null)
                {
                    city.CityCount = active ? city.CityCount + 1 : city.CityCount - 1;
                }
                await _uow.CompleteAsync();
            }
            return Map(project, new ProjectVm());
        }

        private Project Map(ProjectVm project, Project existing)
        {
            var curTime = DateTime.UtcNow;

            existing.Name = project.Name;
            existing.NameAr = project.NameAr;
            existing.NameRu = project.NameRu;
            existing.NameCh = project.NameCh;
            existing.Description = project.Description;
            existing.DescriptionAr = project.DescriptionAr;
            existing.DescriptionRu = project.DescriptionRu;
            existing.DescriptionCh = project.DescriptionCh;
            existing.Address = project.Address;
            existing.AddressAr = project.AddressAr;
            existing.AddressRu = project.AddressRu;
            existing.AddressCh = project.AddressCh;
            existing.AboutLocation = project.AboutLocation;
            existing.AboutLocationAr = project.AboutLocationAr;
            existing.AboutLocationCh = project.AboutLocationCh;
            existing.AboutLocationRu = project.AboutLocationRu;
            existing.Slug = project.Slug;
            existing.VideoUrl = project.VideoUrl;
            existing.StartingPrice = project.StartingPrice;
            existing.Units = project.Units;
            existing.Size = project.Size;
            existing.Handover = project.Handover;
            existing.Stickers = string.Join(";", project.Stickers);
            existing.MapCoordinates = project.MapCoordinates;
            existing.CityId = project.CityId;
            existing.AreaId = project.AreaId;
            existing.UpdatedDate = curTime;

            existing.Images.MarkAsDeleted();
            AddImages(project, existing);

            if (existing.Images.Count > 0)
            {
                existing.ImagePath = existing.Images.FirstOrDefault()?.FullPath;
            }



            SetAmenities(existing, project);
            SetStickers(existing, project);
            SetPaymentPlan(existing, project);
            SetFloorPlan(existing, project);
            SetCategories(existing, project);

            return existing;
        }

        private void AddImages(ProjectVm project, Project existing)
        {
            foreach (var img in project.Images)
            {
                var file = _tokenService.ParseToken<FileVm>(img.Token ?? "");
                if (file is not null)
                {
                    existing.Images.Add(new FileModel
                    {
                        MimeType = file.MimeType,
                        Name = file.Name,
                        FullPath = file.FullPath,
                        RelativePath = file.RelativePath,
                    });
                }
            }
            foreach (var img in project.LocationImages)
            {
                var file = _tokenService.ParseToken<FileVm>(img.Token ?? "");
                if (file is not null)
                {
                    existing.Images.Add(new FileModel
                    {
                        SubType = AppConstants.LocationImageType,
                        MimeType = file.MimeType,
                        Name = file.Name,
                        FullPath = file.FullPath,
                        RelativePath = file.RelativePath,
                    });
                }
            }
        }

        private ProjectFloorPlan Map(FloorPlanVm source, int projId)
        {
            var file = _tokenService.ParseToken<Common.FileVm>(source.ImageToken ?? "");
            return new ProjectFloorPlan
            {
                ProjectId = projId,
                Price = source.Price,
                ImagePathFull = file?.FullPath,
                ImagePath = file?.RelativePath,
                Size = source.Size,
                Type = source.Type,
                TypeAr = source.TypeAr,
                TypeCh = source.TypeCh,
                TypeRu = source.TypeRu,
                UnitType = source.UnitType,
                CategoryId = source.CategoryId,
            };
        }
        private FloorPlanVm Map(ProjectFloorPlan source)
        {
            var token = _tokenService.CreateToken(new Common.FileVm
            {
                FullPath = source.ImagePathFull,
                RelativePath = source.ImagePath
            });
            return new FloorPlanVm
            {
                ProjectId = source.ProjectId,
                Price = source.Price,
                ImagePath = source.ImagePath,
                ImagePathFull = source.ImagePathFull,
                ImageToken = token,
                Size = source.Size,
                Type = GetTranslatedValue(nameof(source.Type), source, source.Type),
                TypeAr = source.TypeAr,
                TypeCh = source.TypeCh,
                TypeRu = source.TypeRu,
                UnitType = source.UnitType,
                Id = source.Id,
                CategoryId = source.CategoryId,
            };
        }
        private ProjectVm Map(Project source, ProjectVm dest)
        {
            dest.Id = source.Id;
            dest.Name = GetTranslatedValue(nameof(source.Name), source, source.Name);
            dest.Description = GetTranslatedValue(nameof(source.Description), source, source.Description);
            dest.Address = GetTranslatedValue(nameof(source.Address), source, source.Address);
            dest.AboutLocation = GetTranslatedValue(nameof(source.AboutLocation), source, source.AboutLocation);

            dest.NameAr = source.NameAr;
            dest.NameRu = source.NameRu;
            dest.NameCh = source.NameCh;
            dest.DescriptionAr = source.DescriptionAr;
            dest.DescriptionRu = source.DescriptionRu;
            dest.DescriptionCh = source.DescriptionCh;
            dest.AddressAr = source.AddressAr;
            dest.AddressRu = source.AddressRu;
            dest.AddressCh = source.AddressCh;
            dest.AboutLocationAr = source.AboutLocationAr;
            dest.AboutLocationCh = source.AboutLocationCh;
            dest.AboutLocationRu = source.AboutLocationRu;
            dest.Slug = source.Slug + "-" + source.Id.ToString();
            dest.VideoUrl = source.VideoUrl;
            dest.StartingPrice = source.StartingPrice;
            dest.Handover = source.Handover;
            //dest.Stickers = source.Stickers?.Split(";") ?? Enumerable.Empty<string>();
            dest.MapCoordinates = source.MapCoordinates;
            dest.Units = source.Units;
            dest.Size = source.Size;
            dest.Active = source.Active;

            dest.CityId = source.CityId;
            if (source.City is not null)
            {
                dest.City = source.City;
                dest.City.Name = GetTranslatedValue(nameof(CityModel.Name), source.City, source.City.Name);
            }

            dest.AreaId = source.AreaId;
            if (source.Area is not null)
            {
                dest.Area = source.Area;
                dest.Area.Name = GetTranslatedValue(nameof(AreaModel.Name), source.Area, source.Area.Name);
            }


            dest.ImagePath = source.ImagePath;

            //dest.CategoryId = source.CategoryId;
            //if (source.Category is not null)
            //{
            //    dest.Category = Map(source.Category, new PropertyCategoryVm());
            //}

            dest.FloorPlan = source.FloorPlan.Select(Map);

            dest.UpdatedDate = source.UpdatedDate;
            dest.CreatedDate = source.CreatedDate;

            dest.Amenities = Map(source.Amenities);
            dest.Stickers = Map(source.Stickers2);
            dest.Categories = source.Categories.Select(Map);
            dest.PaymentPlan = source.PaymentPlan.Select(Map);

            var images = new List<ImageVm>();
            var imagesLoc = new List<ImageVm>();
            foreach (var image in source.Images)
            {
                var token = _tokenService.CreateToken(new Common.FileVm
                {
                    MimeType = image.MimeType,
                    Name = image.Name,
                    FullPath = image.FullPath,
                    RelativePath = image.RelativePath,
                });
                var img = new ImageVm
                {
                    Token = token,
                    Name = image.Name,
                    FullPath = image.FullPath,
                    RelativePath = image.RelativePath,
                };
                if (image.SubType == AppConstants.LocationImageType)
                {
                    imagesLoc.Add(img);
                    continue;
                }
                images.Add(img);
            }
            dest.Images = images;
            dest.LocationImages = imagesLoc;
            return dest;
        }

        private IEnumerable<StickerModelVm> Map(ICollection<StickerModel> stickers2)
        {
            return stickers2.Select(x => new StickerModelVm
            {
                Id = x.Id,
                ProjectId = x.ProjectId,
                Name = GetTranslatedValue(nameof(x.Name), x, x.Name),
                NameAr = x.NameAr,
                NameCh = x.NameCh,
                NameRu = x.NameRu,
            });
        }

        private CategoryVm Map(ProjectCategory src)
        {
            return new CategoryVm
            {
                CategoryId = src.CategoryId,
                //Name = src.Category?.Name,
                Name = GetTranslatedValue(nameof(CategoryModel.Name), src.Category, src.Category?.Name),
                NameAr = src.Category?.NameAr,
                NameCh = src.Category?.NameCh,
                NameRu = src.Category?.NameRu,
            };
        }
        private PaymentPlanVm Map(ProjectPaymentPlan plan)
        {
            return new PaymentPlanVm
            {
                Id = plan.Id,
                Name = GetTranslatedValue(nameof(plan.Name), plan, plan.Name),
                NameAr = plan.NameAr,
                NameCh = plan.NameCh,
                NameRu = plan.NameRu,
                Amount = plan.Amount,
                ProjectId = plan.ProjectId,
            };
        }
        private IEnumerable<AmenityVm> Map(ICollection<ProjectAmenity> amenities)
        {

            return amenities.Select(x => new AmenityVm
            {
                AmenityId = x.AmenityId,
                Name = GetTranslatedValue(nameof(x.Amenity.Name), x.Amenity, x.Amenity?.Name),
                Code = x.Amenity?.Code,
                NameAr = x.Amenity?.NameAr,
                NameCh = x.Amenity?.NameCh,
                NameRu = x.Amenity?.NameRu,
            });
        }
        private CategoryVm? Map(CategoryModel source, CategoryVm dest)
        {
            dest.CategoryId = source.Id;
            dest.Name = source.Name;
            dest.NameAr = source.NameAr;
            dest.NameRu = source.NameRu;
            dest.NameCh = source.NameCh;
            dest.PropertyCount = source.PropertyCount;
            return dest;
        }


        private static void SetStickers(Project existing, ProjectVm project)
        {
            existing.Stickers2.Clear();
            foreach (var am in project.Stickers)
            {
                existing.Stickers2.Add(new StickerModel
                {
                    Name = am.Name,
                    NameAr = am.NameAr,
                    NameCh = am.NameCh,
                    NameRu = am.NameRu
                });
            }
        }
        private static void SetCategories(Project existing, ProjectVm project)
        {
            existing.Categories.Clear();
            foreach (var cat in project.Categories)
            {
                existing.Categories.Add(new ProjectCategory { CategoryId = cat.CategoryId });
            }
        }
        private static void SetAmenities(Project existing, ProjectVm project)
        {
            existing.Amenities.Clear();
            foreach (var am in project.Amenities)
            {
                existing.Amenities.Add(new ProjectAmenity { AmenityId = am.AmenityId });
            }
        }
        private static void SetPaymentPlan(Project existing, ProjectVm project)
        {
            existing.PaymentPlan.Clear();
            foreach (var pp in project.PaymentPlan)
            {
                existing.PaymentPlan.Add(new ProjectPaymentPlan
                {
                    Name = pp.Name,
                    NameAr = pp.NameAr,
                    NameCh = pp.NameCh,
                    NameRu = pp.NameRu,
                    Amount = pp.Amount
                });
            }
        }
        private void SetFloorPlan(Project existing, ProjectVm project)
        {
            existing.FloorPlan.Clear();
            foreach (var fp in project.FloorPlan)
            {
                var img = !string.IsNullOrEmpty(fp.ImageToken)
                    ? _tokenService.ParseToken<FileToken>(fp.ImageToken)
                    : null;
                existing.FloorPlan.Add(new ProjectFloorPlan
                {

                    //ProjectId = project.Id,
                    Price = fp.Price,
                    ImagePathFull = img?.FullPath,
                    ImagePath = img?.RelativePath,
                    Size = fp.Size,
                    Type = fp.Type,
                    TypeAr = fp.TypeAr,
                    TypeCh = fp.TypeCh,
                    TypeRu = fp.TypeRu,
                    UnitType = fp.UnitType,
                    CategoryId = fp.CategoryId,
                });
            }
        }
        private string? GetTranslatedValue<T>(string propName, T source, string? defaultValue)
        {
            if (string.IsNullOrEmpty(_user.LangPropertySuffix))
            {
                return defaultValue;
            }
            var type = typeof(T);
            var property = type.GetProperty(propName + _user.LangPropertySuffix);
            if (property is not null)
            {
                return property.GetValue(source)?.ToString();
            }
            return defaultValue;
        }


        internal async Task ImgProcessing(IEnumerable<ImageVm> files)
        {
            //var curTime = DateTime.UtcNow;

            foreach (var file in files)
            {
                //var destDir = Path.Combine(AppConstants.PermanentFilesDirPath, file.Name!.ToString());

                var destDir = Path.Combine($@"D:\\AltairProjects\\altair-real-estate-backend-v2\\WebApi\\wwwroot\\uploads\\project-images", file.Name!.ToString());

                if (!Directory.Exists(destDir))
                {
                    Directory.CreateDirectory(destDir);
                }
                var tempPath = file.FullPath?.Replace("/", "\\").TrimStart('\\');
                //var srcPath = Path.Combine(AppConstants.TempFilesDirectoryPath, tempPath ?? "");
                var srcPath = Path.Combine($@"D:\\AltairProjects\\altair-real-estate-backend-v2\\WebApi\\wwwroot\\uploads\\temp", tempPath ?? "");
                var destPath = Path.Combine(destDir, Path.GetFileName(srcPath));

                if (File.Exists(srcPath))
                {
                    //File.Move(srcPath, destPath, true);
                    File.Copy(srcPath, destPath, true);
                }
            }
        }








        //private static void UpdateDatabase(SqlConnection connection, int imageId, string newPath)
        //{
        //    connection.Execute("UPDATE Property_Images SET Path = @NewPath WHERE Id = @ImageId", new { NewPath = newPath, ImageId = imageId });
        //}
        //UpdateDatabase(connection, file.Id, destPath);

        //public class PropertyImage
        //{
        //    public int Id { get; set; }
        //    public int PropertyId { get; set; }
        //    public string? Path { get; set; }
        //}
    }
}