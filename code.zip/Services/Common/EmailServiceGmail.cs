﻿using SendGrid.Helpers.Mail;
using SendGrid;
using System.Net.Mail;
using System.Net;

namespace WebApi.Services.Common
{
    public class EmailServiceGmail
    {
        protected readonly IConfiguration _configs;
        protected readonly ILogger<EmailService> _logger;
        //protected readonly string _emailTemplateConfirmEmail;

        public EmailServiceGmail(IConfiguration configs,
             ILogger<EmailService> logger
            )
        {
            _configs = configs;
            _logger = logger;
            //_emailTemplateConfirmEmail = File.ReadAllText("EmailTemplates/email-varification.html");
        }

        public Task SendEmail(string to, string toName, string subject, string body, string from="no-reply <no-reply@altairre.ae>")
        {
            var user = _configs.GetValue<string>("GmailUsername");
            var password = _configs.GetValue<string>("GmailPassword");
            
            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(user, password),
                EnableSsl = true,
            };

            var message = new MailMessage
            {
                From = new MailAddress(from),
                Subject =subject,
                Body = body,
                //IsBodyHtml = true,
            };

            message.To.Add(to);

            return smtpClient.SendMailAsync(message);

        }
        //public Task SendEmailConfirmationToken(string email, int userId, string userName, string token)
        //{
        //    var body = _emailTemplateConfirmEmail
        //        .Replace("[email_token]", token)
        //        .Replace("[user_id]", userId.ToString());
        //    return SendEmail(email, userName, $"Welcome {userName}", body);
        //}
    }
}
