﻿using FluentValidation;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.ViewModels.Filters;
using WebApi.ViewModels;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using WebApi.Common.Models;
using System.Reflection;
using WebApi.Common;
using System.Linq;
using WebApi.Common.Exceptions;
using WebApi.Persistence.Repository;

namespace WebApi.Services
{
    public class PropertyService
    {

        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly TokenService _tokenService;
        //private readonly IConfiguration _configs;
        //private readonly Type _propertyType = typeof(Property);
        private readonly UploadService _upload;

        public PropertyService(UnitOfWork uow, TokenService tokenService,
            //IConfiguration configs,
            LoggedInUser user, UploadService upload)
        {
            _uow = uow;
            _tokenService = tokenService;
            //_configs = configs;
            _user = user;
            _upload = upload;
        }

        public async Task<Property> Save(PropertyVm property)
        {
            //Property? existingProp = null;
            var existing = property.Id.HasValue && property.Id > 0 ? await _uow.Properties.GetDetails(property.Id.Value) : null;

            var propNew = Map(property, existing ?? new Property());
            propNew.Slug = Utilities.CreateSlug(property.Name ?? "");
            if (existing is null)
            {
                propNew.CreatedDate = propNew.UpdatedDate;
                propNew.AgentId = _user.UserId;
                propNew.Active = true;

                var category = await _uow.PropertyCategories.Find(property.CategoryId);
                if (category != null)
                {
                    category.PropertyCount++;
                }
                var area = await _uow.PropertyAreas.Find(property.AreaId);
                if (area != null)
                {
                    area.AreaCount++;
                }
                var city = await _uow.PropertyCities.Find(property.CityId);
                if (city != null)
                {
                    city.CityCount++;
                }

                propNew = await _uow.Properties.Add(propNew);
            }

            await _uow.CompleteAsync();

            return propNew;
        }

        internal async Task<PropertyVm> GetProperty(string slug)
        {
            var propId = Utilities.GetIdFromSlug(slug);
            var property = await _uow.Properties.GetDetails(propId);

            return property is null
                ? throw new Exception($"Property with Id:{propId} not found")
                : Map(property, new PropertyVm());
        }
        public async Task<DataPageModel<PropertyVm>> Filter(PropertyFilter filter, int? agentId = null)
        {
            var data = await _uow.Properties.Filter(filter, agentId);

            return new DataPageModel<PropertyVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new PropertyVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };
        }
        internal async Task<DataPageModel<GetBookingVm>> GetUserBookingProperties(FilterBase filter)
        {
            var data = await _uow.Bookings.Filter(filter, _user.UserId, true);
            return new DataPageModel<GetBookingVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new GetBookingVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };
        }
        internal async Task<IEnumerable<PropertyFavoriteVm>> GetUserFavoriteProperties()
        {
            var data = await _uow.PropertyFavorites.GetUserFavorites(_user.UserId);
            return data.ToList().Select(x => Map(x, new PropertyFavoriteVm()));
        }

        internal async Task<PropertyVm> ChangeUserPropertyStatus(int propId, bool active)
        {
            var property = await _uow.Properties.FindOne(x => x.Id == propId && x.AgentId == _user.UserId)
                ?? throw new AppBadRequestException($"Property with id:{propId} for logged in user not found.");

            if (property.Active != active)
            {
                property.Active = active;
                var category = await _uow.PropertyCategories.Find(property.CategoryId);
                if (category != null)
                {
                    if (property.Active)
                        category.PropertyCount++;
                    if (!property.Active)
                        category.PropertyCount--;
                }
                var area = await _uow.PropertyAreas.Find(property.AreaId);
                if (area != null)
                {
                    area.AreaCount = active ? area.AreaCount + 1 : area.AreaCount - 1;
                }
                var city = await _uow.PropertyCities.Find(property.CityId);
                if (city != null)
                {
                    city.CityCount = active ? city.CityCount + 1 : city.CityCount - 1;
                }
                await _uow.CompleteAsync();
            }
            return Map(property, new PropertyVm());
        }
        private PropertyFavoriteVm Map(PropertyFavorite source, PropertyFavoriteVm dest)
        {
            dest.Id = source.Id;
            dest.PropertyId = source.PropertyId;
            dest.CreatedDate = source.CreatedDate;
            dest.Active = source.Active;
            dest.UserId = source.UserId;

            if (source.Property is not null)
                dest.Property = Map(source.Property, new PropertyVm());

            return dest;
        }

        private GetBookingVm Map(Booking source, GetBookingVm dest)
        {
            dest.Id = source.Id;
            dest.PropertyId = source.PropertyId;
            dest.NoteToAgent = source.NoteToAgent;
            dest.Date = source.Date;
            dest.Email = source.Email;
            dest.FullName = source.FullName;
            dest.Contact = source.Contact;
            dest.Gender = source.Gender;

            dest.Closed = source.Closed;
            dest.AgentId = source.AgentId;
            dest.UserId = source.UserId;
            dest.Country = source.Country;

            if (source.Property is not null)
                dest.Property = Map(source.Property, new PropertyVm());

            return dest;
        }

        private Property Map(PropertyVm property, Property existing)
        {
            var curTime = DateTime.UtcNow;

            existing.Name = property.Name;
            existing.NameAr = property.NameAr;
            existing.NameRu = property.NameRu;
            existing.NameCh = property.NameCh;
            existing.Description = property.Description;
            existing.DescriptionAr = property.DescriptionAr;
            existing.DescriptionRu = property.DescriptionRu;
            existing.DescriptionCh = property.DescriptionCh;
            existing.Address = property.Address;
            existing.AddressAr = property.AddressAr;
            existing.AddressRu = property.AddressRu;
            existing.AddressCh = property.AddressCh;
            existing.Bedroom = property.Bedroom;
            existing.VideoUrl = property.VideoUrl;
            existing.Bathroom = property.Bathroom;
            existing.Floor = property.Floor;
            existing.TotalFloor = property.TotalFloor;
            existing.Size = property.Size;
            existing.MapCoordinates = property.MapCoordinates;
            existing.Price = property.Price;
            existing.CategoryId = property.CategoryId;
            existing.CityId = property.CityId;
            existing.AreaId = property.AreaId;
            existing.IsRental = property.IsRental;
            existing.IsStudio = property.IsStudio;
            existing.RentPerMonth = property.RentPerMonth;
            existing.RentPerDay = property.RentPerDay;
            existing.BestOffer = property.BestOffer;
            existing.UpdatedDate = curTime;

            existing.Images.MarkAsDeleted();

            foreach (var img in property.Images)
            {
                var file = _tokenService.ParseToken<FileModel>(img.Token ?? "");
                if (file is not null)
                {
                    existing.Images.Add(new FileModel
                    {
                        MimeType = file.MimeType,
                        Name = file.Name,
                        FullPath = file.FullPath,
                        RelativePath = file.RelativePath,
                    });
                }
            }

            if (existing.Images.Count > 0)
            {
                existing.ImagePath = existing.Images.FirstOrDefault()?.FullPath;
            }

            SetAmenities(existing, property);

            return existing;
        }

        private static void SetAmenities(Property existing, PropertyVm property)
        {
            existing.Amenities.Clear();
            foreach (var am in property.Amenities)
            {
                existing.Amenities.Add(new PropertyAmenity { AmenityId = am.AmenityId });
            }
        }

        private PropertyVm Map(Property source, PropertyVm dest)
        {
            dest.Id = source.Id;
            dest.Name = GetTranslatedValue(nameof(source.Name), source, source.Name);
            dest.Description = GetTranslatedValue(nameof(source.Description), source, source.Description);
            dest.Address = GetTranslatedValue(nameof(source.Address), source, source.Address);

            dest.NameAr = source.NameAr;
            dest.NameRu = source.NameRu;
            dest.NameCh = source.NameCh;
            dest.DescriptionAr = source.DescriptionAr;
            dest.DescriptionRu = source.DescriptionRu;
            dest.DescriptionCh = source.DescriptionCh;
            dest.AddressAr = source.AddressAr;
            dest.AddressRu = source.AddressRu;
            dest.AddressCh = source.AddressCh;
            dest.Slug = source.Slug + "-" + source.Id.ToString();
            dest.Bedroom = source.Bedroom;
            dest.VideoUrl = source.VideoUrl;
            dest.Bathroom = source.Bathroom;
            dest.Floor = source.Floor;
            dest.TotalFloor = source.TotalFloor;
            dest.Size = source.Size;
            dest.MapCoordinates = source.MapCoordinates;
            dest.Price = source.Price;
            dest.Active = source.Active;
            dest.IsRental = source.IsRental;
            dest.IsStudio = source.IsStudio;
            dest.RentPerDay = source.RentPerDay;
            dest.RentPerMonth = source.RentPerMonth;
            dest.BestOffer = source.BestOffer;
            dest.CityId = source.CityId;
            if (source.City is not null)
            {
                dest.City = source.City;
                dest.City.Name = GetTranslatedValue(nameof(CityModel.Name), source.City, source.City.Name);

            }
            dest.AreaId = source.AreaId;
            if (source.Area is not null)
            {
                dest.Area = source.Area;
                dest.Area.Name = GetTranslatedValue(nameof(AreaModel.Name), source.Area, source.Area.Name);

            }

            dest.ImagePath = source.ImagePath;
            dest.CategoryId = source.CategoryId;

            if (source.Category is not null)
            {
                dest.Category = Map(source.Category, new CategoryVm());
            }

            dest.Stars1 = source.Stars1;
            dest.Stars2 = source.Stars2;
            dest.Stars3 = source.Stars3;
            dest.Stars4 = source.Stars4;
            dest.Stars5 = source.Stars5;

            dest.UpdatedDate = source.UpdatedDate;
            dest.CreatedDate = source.CreatedDate;

            dest.User = Map(source.User, new UserVm());
            dest.Amenities = Map(source.Amenities);

            //if (source.User is not null)
            //{
            //    dest.User = source.User;
            //}

            var images = new List<ImageVm>();
            foreach (var img in source.Images)
            {
                var token = _tokenService.CreateToken(new FileModel
                {
                    MimeType = img.MimeType,
                    Name = img.Name,
                    FullPath = img.FullPath,
                    RelativePath = img.RelativePath,
                });
                images.Add(new ImageVm
                {
                    Token = token,
                    Name = img.Name,
                    FullPath = img.FullPath,
                    RelativePath = img.RelativePath
                });
            }
            dest.Images = images;
            return dest;
        }

        private IEnumerable<AmenityVm> Map(ICollection<PropertyAmenity> amenities)
        {
            return amenities.Select(x => new AmenityVm
            {
                AmenityId = x.AmenityId,
                Name = GetTranslatedValue(nameof(x.Amenity.Name), x.Amenity, x.Amenity?.Name),
                Code = x.Amenity?.Code,
                NameAr = x.Amenity?.NameAr,
                NameCh = x.Amenity?.NameCh,
                NameRu = x.Amenity?.NameRu,
            });
        }

        private CategoryVm? Map(CategoryModel source, CategoryVm dest)
        {
            dest.CategoryId = source.Id;
            dest.Name = GetTranslatedValue(nameof(source.Name), source, source.Name);
            dest.NameAr = source.NameAr;
            dest.NameRu = source.NameRu;
            dest.NameCh = source.NameCh;
            dest.PropertyCount = source.PropertyCount;
            return dest;
        }

        internal async Task<object> GetMasterData()
        {

            var Categories = (await _uow.PropertyCategories.All()).Select(Map);
            var Rooms = await _uow.Properties.AllRooms();
            var Cities = (await _uow.PropertyCities.All()).Select(Map);
            var Areas = (await _uow.PropertyAreas.All()).Select(Map);
            var Amenities = (await _uow.Properties.AllAmenities()).Select(Map);
            return new
            {
                Categories,
                Rooms,
                Cities,
                Areas,
                Amenities
            };
        }

        private Amenity Map(Amenity src)
        {

            return new Amenity
            {
                Id = src.Id,
                Name = GetTranslatedValue(nameof(src.Name), src, src.Name),
                Code = src.Code,
                NameAr = src.NameAr,
                NameCh = src.NameCh,
                NameRu = src.NameRu,
            };
        }


        private AreaModel Map(AreaModel src)
        {
            return new AreaModel
            {
                Id = src.Id,
                Name = GetTranslatedValue(nameof(AreaModel.Name), src, src.Name),
                NameAr = src.NameAr,
                NameCh = src.NameCh,
                NameRu = src.NameRu,
                AreaCount = src.AreaCount,
                CityId = src.CityId,
                Active = src.Active,
            };
        }
        private CityModel Map(CityModel src)
        {
            return new CityModel
            {
                Id = src.Id,
                Name = GetTranslatedValue(nameof(CityModel.Name), src, src.Name),
                NameAr = src.NameAr,
                NameCh = src.NameCh,
                NameRu = src.NameRu,
                CityCount = src.CityCount,
                Active = src.Active,
            };
        }
        private CategoryModel Map(CategoryModel src)
        {
            return new CategoryModel
            {
                Id = src.Id,
                Name = GetTranslatedValue(nameof(CategoryModel.Name), src, src.Name),
                NameAr = src.NameAr,
                NameCh = src.NameCh,
                NameRu = src.NameRu,
                PropertyCount = src.PropertyCount,
                IconPath = src.IconPath,
            };
        }
        private UserVm? Map(User? source, UserVm dest)
        {
            if (source is null) return null;

            dest.FirstName = source.FirstName;
            dest.LastName = source.LastName;
            dest.ProfilePhoto = source.ProfilePhoto;
            dest.Contact = source.Contact;
            dest.Id = source.Id;

            return dest;
        }

        private string? GetTranslatedValue<T>(string propName, T source, string? defaultValue)
        {
            if (string.IsNullOrEmpty(_user.LangPropertySuffix))
            {
                return defaultValue;
            }
            var type = typeof(T);
            var property = type.GetProperty(propName + _user.LangPropertySuffix);
            if (property is not null)
            {
                return property.GetValue(source)?.ToString();
            }
            return defaultValue;
        }
    }
}
