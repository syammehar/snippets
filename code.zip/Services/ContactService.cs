﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using WebApi.Common;
using WebApi.Common.Exceptions;
using WebApi.Common.Models;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Services
{
    public class ContactService
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly TokenService _tokenService;
        private readonly UploadService _upload;
        private readonly EmailServiceGmail _email2;
        protected readonly IConfiguration _configs;
        protected readonly ILogger<ContactService> _logger;

        public ContactService(UnitOfWork uow,
            LoggedInUser user,
            TokenService tokenService,
            UploadService upload,
            EmailServiceGmail email2,
            IConfiguration configs,
            ILogger<ContactService> logger)
        {
            _uow = uow;
            _user = user;
            _tokenService = tokenService;
            _upload = upload;
            _email2 = email2;
            _configs = configs;
            _logger = logger;
        }


        public async Task<Contact> Save(ContactVm contact)
        {
            var curTime = DateTime.UtcNow;
            var contNew = Map(contact, new Contact());

            contNew.CreatedDate = curTime;
            contNew.UpdatedDate = curTime;
            contNew.Active = true;
            contNew = await _uow.Contacts.Add(contNew);

            if (contNew.PropertyId.HasValue && contNew.PropertyId > 0)
            {
                contNew.Property = await _uow.Properties.Find(contNew.PropertyId.Value);
                contNew.ItemName = contNew.Property?.Name;
            }
            else if (contNew.ProjectId.HasValue && contNew.ProjectId > 0)
            {
                contNew.Project = await _uow.Projects.Find(contNew.ProjectId.Value);
                contNew.ItemName = contNew.Project?.Name;
            }
            await _uow.CompleteAsync();

            NotifyLeadsEmail(contNew);

            return contNew;
        }

        private async Task NotifyLeadsEmail(Contact contNew)
        {
            try
            {
                var leadsEmail = _configs.GetValue<string>("LeadsEmail");
                if (string.IsNullOrEmpty(leadsEmail)
                    || contNew.ContactType == AppConstants.ContactTypeSubscription)
                {

                    return;
                }
                var body = $@"
A new contact has been submitted
User Name: {contNew.Name}
Email: {contNew.Email}
Phone: {contNew.Phone}
Message: {contNew.Message}
Inquiry Type: {contNew.ContactType}
Project/Property: {contNew.ItemName}
ProjectId: {contNew.ProjectId}
PropertyId: {contNew.PropertyId}

";
                await _email2.SendEmail(leadsEmail, "", "New Contact Submitted", body);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Leads email notification failed.");
            }

        }

        public Contact Map(ContactVm src, Contact dest)
        {
            dest.Name = src.Name;
            dest.Phone = src.Phone;
            dest.Email = src.Email;
            dest.Message = src.Message;
            dest.PropertyId = src.PropertyId;
            dest.ProjectId = src.ProjectId;
            dest.ContactType = src.ContactType;

            return dest;
        }

        public async Task<DataPageModel<ContactVm>> Filter(FilterBase filter)
        {
            var data = await _uow.Contacts.Filter(filter);

            return new DataPageModel<ContactVm>
            {
                Data = data.Data.ToList().Select(x => Map(x, new ContactVm())),
                Count = data.Count,
                PageCount = data.PageCount,
            };
        }

        private ContactVm Map(Contact source, ContactVm dest)
        {
            dest.Id = source.Id;
            dest.Name = source.Name;
            dest.Phone = source.Phone;
            dest.Email = source.Email;
            dest.Message = source.Message;
            dest.PropertyId = source.PropertyId;
            dest.ProjectId = source.ProjectId;
            dest.ItemName = source.ItemName;
            dest.ContactType = source.ContactType;
            dest.Active = source.Active;
            dest.CreatedDate = source.CreatedDate;
            dest.UpdatedDate = source.UpdatedDate;

            return dest;
        }

        internal async Task<ContactVm> ChangeStatus(int id, bool active)
        {
            var status = await _uow.Contacts.FindOne(x => x.Id == id)
                ?? throw new AppBadRequestException($"Contact with id:{id} not found.");

            var curTime = DateTime.UtcNow;
            if (status.Active != active)
            {
                status.Active = active;
                status.UpdatedDate = curTime;
                await _uow.CompleteAsync();
            }

            return Map(status, new ContactVm());
        }

    }
}
