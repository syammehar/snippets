﻿namespace WebApi.Common.Exceptions
{

    public class InvalidSlugException : Exception
    {
        public InvalidSlugException(string slug) : base($"'{slug}' is not a valid id.")
        {

        }
    }
}
