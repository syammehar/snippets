﻿namespace WebApi.Common
{
    public class AppConstants
    {
        public const string FirebaseKeyFilePath = "FirebaseKeyFilePath";
        public const string ContactTypeSubscription = "subscription";
        public const string ApiExchangeRateClientName = "ExchangeRateClient";
        public const string TempFilesDirectoryPath = "TempFilesDirectory";
        public const string PermanentFilesDirPath = "PermanentFilesDir";
        public const string LocationImageType = "location";
    }
    public class Roles
    {
        public const string Admin = "admin";
        public const string Manager = "manager";
    }
}
