﻿using WebApi.Common.Exceptions;

namespace WebApi.Common
{
    public class Utilities
    {
        public static string CreateSlug(string str)
        {
            var arr = str.ToCharArray();
            arr = Array.FindAll(arr, (c => (char.IsLetterOrDigit(c)
                                              || char.IsWhiteSpace(c)
                                              || c == '-')));
            return string.Join("-", new string(arr).Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(x => x.ToLower()));
        }

        internal static int GetIdFromSlug(string slug)
        {
            var idStr = slug.Split("-").Last();
            if (int.TryParse(idStr, out int id))
            {
                return id;
            }
            throw new InvalidSlugException(slug);
        }
    }
}
