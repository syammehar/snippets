﻿using WebApi.Models.Entities;
using WebApi.Services.Common;

namespace WebApi.ViewModels
{
    public class PropertyVms
    {
    }
    public class PropertyVm
    {
        public PropertyVm()
        {
            Images = new List<ImageVm>();
            Amenities = new List<AmenityVm>();
        }
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? NameAr { get; set; }
        public string? DescriptionAr { get; set; }
        public string? NameRu { get; set; }
        public string? DescriptionRu { get; set; }
        public string? NameCh { get; set; }
        public string? DescriptionCh { get; set; }
        public string? Address { get; set; }
        public string? AddressAr { get; set; }
        public string? AddressRu { get; set; }
        public string? AddressCh { get; set; }
        public string? Slug { get; set; }
        public string? VideoUrl { get; set; }
        public int Bedroom { get; set; }
        public int Bathroom { get; set; }
        public int Floor { get; set; }
        public int TotalFloor { get; set; }
        public decimal? Size { get; set; }
        public string? MapCoordinates { get; set; }
        public object? LatLng
        {
            get
            {
                var arr = MapCoordinates?.Split(",");
                if (arr?.Length < 2)
                {
                    return null;
                }
                if (double.TryParse(arr?[0].Trim(), out var lat) && double.TryParse(arr?[1].Trim(), out var lng))
                {
                    return new { lat, lng };
                }
                return null;
            }
        }
        public decimal Price { get; set; }
        public int Stars1 { get; set; }
        public int Stars2 { get; set; }
        public int Stars3 { get; set; }
        public int Stars4 { get; set; }
        public int Stars5 { get; set; }
        public decimal Rating
        {
            get
            {
                var sum = (decimal)Stars1 + Stars2 + Stars3 + Stars4 + Stars5;
                if (sum < 1) return 0;

                return (Stars1 + (Stars2 * 2) + (Stars3 * 3) + (Stars4 * 4) + (Stars5 * 5))
                    / sum;
            }
        }         
        public int ReviewsCount
        {
            get
            {
                return Stars1 + Stars2 + Stars3 + Stars4 + Stars5;
            }
        }
        public bool Active { get; set; }
        public int CategoryId { get; set; }
        public int CityId { get; set; }
        public int AreaId { get; set; }
        public CategoryVm? Category { get; set; }
        public CityModel? City { get; set; }
        public AreaModel? Area { get; set; }
        public bool IsRental { get; set; }
        public bool IsStudio { get; set; }
        public decimal RentPerMonth { get; set; }
        public decimal RentPerDay { get; set; }
        public bool BestOffer { get; set; }
        public string? ImagePath { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public UserVm? User { get; set; }
        public IEnumerable<ImageVm> Images { get; set; }
        public IEnumerable<AmenityVm> Amenities { get; set; }
    }
    public class ImageVm
    {
        public string? Token { get; set; }
        public string? Name { get; set; }
        public string? RelativePath { get; set; }
        public string? FullPath { get; set; }
    }
    public class PropertyFavoriteVm
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int PropertyId { get; set; }
        public bool Active { get; set; }
        public PropertyVm? Property { get; set; }
        public DateTime CreatedDate { get; set; }
    }
    //public class UserPiiVm
    //{
    //    public int Id { get; set; }
    //    public string? FirstName { get; set; }
    //    public string? LastName { get; set; }
    //    public string? Contact { get; set; }
    //    public string? Email { get; set; }
    //    public string? ProfilePhoto { get; set; }
    //}
    public class UserVm
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Contact { get; set; }
        public string? ProfilePhoto { get; set; }
        public bool IsOnline { get; set; }
    }


    public class AmenityVm
    {
        public int AmenityId { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; }
        public string? NameCh { get; set; }
    }

    public class CategoryVm
    {
        public int CategoryId { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameRu { get; set; }
        public string? NameCh { get; set; }
        public string? IconPath { get; set; }
        public int PropertyCount { get; set; }
    }

    public class TestimonialVm
    {
        public TestimonialVm()
        {
            Images = new HashSet<FileToken>();
        }
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Title { get; set; }
        public string? Comments { get; set; }
        public string? ProfilePhoto { get; set; }
        public int Star { get; set; }
        public ICollection<FileToken> Images { get; set; }
        public bool Active { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
