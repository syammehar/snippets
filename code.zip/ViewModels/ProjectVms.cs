﻿using WebApi.Models.Entities;
using WebApi.Services.Common;

namespace WebApi.ViewModels
{
    public class ProjectVms
    {
    }

    public class ProjectVm
    {
        public ProjectVm()
        {
            FloorPlan = Enumerable.Empty<FloorPlanVm>(); ;
            Amenities = new List<AmenityVm>();
            Stickers = new List<StickerModelVm>();
            Images = new List<ImageVm>();
            LocationImages = new List<ImageVm>();
            Categories = new List<CategoryVm>();
            PaymentPlan = new List<PaymentPlanVm>();
           
        }
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? NameAr { get; set; }
        public string? DescriptionAr { get; set; }
        public string? NameRu { get; set; }
        public string? DescriptionRu { get; set; }
        public string? NameCh { get; set; }
        public string? DescriptionCh { get; set; }
        public string? Address { get; set; }
        public string? AddressAr { get; set; }
        public string? AddressRu { get; set; }
        public string? AddressCh { get; set; }
        public string? AboutLocation { get; set; }
        public string? AboutLocationAr { get; set; }
        public string? AboutLocationCh { get; set; }
        public string? AboutLocationRu { get; set; }
        public string? Slug { get; set; }
        public string? VideoUrl { get; set; }
        public decimal StartingPrice { get; set; }
        public string? Units { get; set; }
        public decimal Size { get; set; }
        public string? Handover { get; set; }
        //public IEnumerable<string> Stickers { get; set; }
        public string? MapCoordinates { get; set; }
        public object? LatLng
        {
            get
            {
                var arr = MapCoordinates?.Split(",");
                if (arr?.Length < 2)
                {
                    return null;
                }
                if (double.TryParse(arr?[0].Trim(), out var lat) && double.TryParse(arr?[1].Trim(), out var lng))
                {
                    return new { lat, lng };
                }
                return null;
            }
        }
        public int CityId { get; set; }
        public int AreaId { get; set; }
        public bool Active { get; set; }
        public string? ImagePath { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public CityModel? City { get; set; }
        public AreaModel? Area { get; set; }
        public IEnumerable<FloorPlanVm> FloorPlan { get; set; }
        public IEnumerable<PaymentPlanVm> PaymentPlan { get; set; }
        public IEnumerable<ImageVm> Images { get; set; }
        public IEnumerable<ImageVm> LocationImages { get; set; }
        public IEnumerable<AmenityVm> Amenities { get; set; }
        public IEnumerable<StickerModelVm> Stickers { get; set; }
        public IEnumerable<CategoryVm> Categories { get; set; }
    }

    public class PaymentPlanVm
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameCh { get; set; }
        public string? NameRu { get; set; }
        public string? Amount { get; set; }
    }

    public class FloorPlanVm
    {
        public int? Id { get; set; }
        public int ProjectId { get; set; }
        public int CategoryId { get; set; }
        public string? Type { get; set; }
        public string? TypeAr { get; set; }
        public string? TypeCh { get; set; }
        public string? TypeRu { get; set; }
        public string? UnitType { get; set; }
        public decimal Size { get; set; }
        public decimal? Price { get; set; }
        public string? ImagePath { get; set; }
        public string? ImagePathFull { get; set; }
        public string? ImageToken { get; set; }
        public CategoryVm? Category { get; set; }


    }

    public class ProjectPaymentPlanVm
    {
        public int? Id { get; set; }
        public int ProjectId { get; set; }
        public string? Name { get; set; }
        public string? Сondition { get; set; }
        public int Percent { get; set; }
        public ProjectVm? Project { get; set; }
    }

    public class StickerModelVm
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string? Name { get; set; }
        public string? NameAr { get; set; }
        public string? NameCh { get; set; }
        public string? NameRu { get; set; }
        public Project? Project { get; set; }
    }

}
