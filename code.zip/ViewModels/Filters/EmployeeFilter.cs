﻿namespace WebApi.ViewModels.Filters
{
    public class EmployeeFilter : FilterBase
    {

        public bool IncludeInActive { get; set; }
    }
}
