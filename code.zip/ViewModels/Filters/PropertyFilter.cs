﻿namespace WebApi.ViewModels.Filters
{
    public class PropertyFilter : FilterBase
    {
        public int? CategoryId { get; set; }
        public string? Search { get; set; }
        public bool? IsRental { get; set; }
        public bool IncludeInActive { get; set; }
        public bool? BestOffer { get; set; }
        public string? Location { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }  
        public decimal? MinArea { get; set; }
        public decimal? MaxArea { get; set; }
        public int? MinBeds { get; set; }
        public int? MaxBeds { get; set; }
        public bool Random { get; set; }
    }
}
