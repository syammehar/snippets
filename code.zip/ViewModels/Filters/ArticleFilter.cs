﻿namespace WebApi.ViewModels.Filters
{
    public class ArticleFilter : FilterBase
    {
        public bool IsBlog { get; set; }
        public bool Random { get; set; }
    }
}
