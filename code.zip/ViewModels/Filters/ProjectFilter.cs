﻿namespace WebApi.ViewModels.Filters
{
    public class ProjectFilter : FilterBase
    {
        public int? CategoryId { get; set; }
        public string? Search { get; set; }
        public int? CityId { get; set; }
        public bool IncludeInActive { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }  
        public decimal? MinArea { get; set; }
        public decimal? MaxArea { get; set; }
        public bool Random { get; set; }
    }
}
