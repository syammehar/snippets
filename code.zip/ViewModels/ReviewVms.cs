﻿namespace WebApi.ViewModels
{
    public class ReviewVms
    {
    }
    public class ReviewVm
    {
        public int Id { get; set; }
        public int PropertyId { get; set; }
        public int UserId { get; set; }
        public int Stars { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public UserVm? User { get; set; }
    }
}
