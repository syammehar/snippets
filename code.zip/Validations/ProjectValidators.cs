﻿using FluentValidation;
using WebApi.ViewModels;

namespace WebApi.Validations
{
    public class ProjectValidators
    {
    }

    public class AddProjectValidator : AbstractValidator<ProjectVm>
    {
        public AddProjectValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 100);
            RuleFor(x => x.Description).NotNull().Length(1, 4000);
            RuleFor(x => x.Address).NotNull().Length(1, 100);
            RuleFor(x => x.MapCoordinates).NotNull().Length(1, 100);
            RuleFor(x => x.Units).NotNull().Length(1, 100);
            //RuleFor(x => x.CategoryId).GreaterThan(0);
            RuleFor(x => x.CityId).GreaterThan(0);
            RuleFor(x => x.AreaId).GreaterThan(0);
        }
    }

    public class AddProjectPaymentPlanValidator : AbstractValidator<ProjectPaymentPlanVm>
    {
        public AddProjectPaymentPlanValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 100);
            RuleFor(x => x.Сondition).NotNull().Length(1, 100);
            RuleFor(x => x.Percent).GreaterThanOrEqualTo(0).LessThanOrEqualTo(100);
        }
    }

    public class AddProjectFloorPlanValidator : AbstractValidator<FloorPlanVm>
    {
        public AddProjectFloorPlanValidator()
        {
            RuleFor(x => x.ProjectId).GreaterThan(0);
            RuleFor(x => x.CategoryId).GreaterThan(0);
            RuleFor(x => x.Type).NotNull().Length(1, 100);
            RuleFor(x => x.TypeAr).NotNull().Length(1, 100);
            RuleFor(x => x.TypeCh).NotNull().Length(1, 100);
            RuleFor(x => x.TypeRu).NotNull().Length(1, 100);
            RuleFor(x => x.UnitType).NotNull().Length(1, 100);
            RuleFor(x => x.Price).GreaterThan(0);
            RuleFor(x => x.Size).GreaterThan(0);
        }
    }
}
