﻿using FluentValidation;
using WebApi.ViewModels;

namespace WebApi.Validations
{
    public class EmployeeValidators
    {
    }

    public class AddEmployeeValidator : AbstractValidator<EmployeeVm>
    {
        public AddEmployeeValidator()
        {
            RuleFor(x => x.FirstName).NotNull().Length(1, 100);
            RuleFor(x => x.LastName).NotNull().Length(1, 100);
            RuleFor(x => x.Position).NotNull().Length(1, 100);
            RuleFor(x => x.Description).NotNull().Length(1, 1000);
            RuleFor(x => x.DescriptionAr).NotNull().Length(1, 1000);
            RuleFor(x => x.DescriptionCh).NotNull().Length(1, 1000);
            RuleFor(x => x.DescriptionRu).NotNull().Length(1, 1000);
            RuleFor(x => x.PhoneNubmer).NotNull().Length(1, 100);
        }
    }
}
