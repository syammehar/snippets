﻿using FluentValidation;
using WebApi.Models.Entities;
using WebApi.ViewModels;

namespace WebApi.Validations
{
    public class ArticleValidators
    {
        public class AddArticleValidators : AbstractValidator<ArticleVm>
        {
            public AddArticleValidators()
            {
                RuleFor(x => x.Title).NotNull().Length(1, 100);
                RuleFor(x => x.TitleAr).NotNull().Length(1, 100);
                RuleFor(x => x.TitleCh).NotNull().Length(1, 100);
                RuleFor(x => x.TitleRu).NotNull().Length(1, 100);
            }
        }

        public class AddArticleSectionValidators : AbstractValidator<ArticleSectionVm>
        {
            public AddArticleSectionValidators()
            {
                RuleFor(x => x.Description).NotNull().Length(1, 4000);
                RuleFor(x => x.DescriptionAr).NotNull().Length(1, 4000);
                RuleFor(x => x.DescriptionCh).NotNull().Length(1, 4000);
                RuleFor(x => x.DescriptionRu).NotNull().Length(1, 4000);
            }
        }
    }
}