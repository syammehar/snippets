﻿using FluentValidation;
using WebApi.Models.Entities;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Validations
{
    public class PropertyValidators
    {
    }
    public class AddPropertyValidator : AbstractValidator<PropertyVm>
    {
        public AddPropertyValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 100);
            RuleFor(x => x.Description).NotNull().Length(1, 4000);
            RuleFor(x => x.Address).NotNull().Length(1, 100);
            RuleFor(x => x.MapCoordinates).NotNull().Length(1, 100);
            RuleFor(x => x.Bedroom).NotNull().GreaterThan(-1);
            RuleFor(x => x.Bathroom).NotNull().GreaterThan(-1);
            RuleFor(x => x.CategoryId).GreaterThan(0);
            RuleFor(x => x.CityId).GreaterThan(0);
            RuleFor(x => x.AreaId).GreaterThan(0);        }
    }
    public class FilterValidator : AbstractValidator<FilterBase>
    {
        public FilterValidator()
        {
            RuleFor(x => x.Page).GreaterThanOrEqualTo(0);
            RuleFor(x => x.PageSize).GreaterThanOrEqualTo(1).LessThanOrEqualTo(100);
        }
    }
}