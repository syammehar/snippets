﻿using FluentValidation;
using WebApi.ViewModels;

namespace WebApi.Validations
{
    public class ContactValidators
    {
    }

    public class AddContactValidator : AbstractValidator<ContactVm>
    {
        public AddContactValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 50);
            RuleFor(x => x.Phone).NotNull().Length(1, 30);
            RuleFor(x => x.Email).NotNull().Length(1, 50);
        }
    }
    //public class AddSubscriptionValidator : AbstractValidator<ContactVm>
    //{
    //    public AddSubscriptionValidator()
    //    {
    //        RuleFor(x => x.Email).NotNull().Length(1, 50);
    //    }
    //}
}
