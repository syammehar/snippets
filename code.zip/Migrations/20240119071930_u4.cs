﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApi.Migrations
{
    /// <inheritdoc />
    public partial class u4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AddressKz",
                table: "Properties");

            migrationBuilder.DropColumn(
                name: "DescriptionKz",
                table: "Properties");

            migrationBuilder.DropColumn(
                name: "NameKz",
                table: "Properties");

            migrationBuilder.DropColumn(
                name: "AddressKz",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "DescriptionKz",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "NameKz",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "DescriptionKz",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "NameKz",
                table: "Amenities");

            migrationBuilder.AddColumn<string>(
                name: "NameAr",
                table: "Project_Payment_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NameCh",
                table: "Project_Payment_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NameRu",
                table: "Project_Payment_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TypeAr",
                table: "Project_Floor_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TypeCh",
                table: "Project_Floor_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TypeRu",
                table: "Project_Floor_Plans",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Project_Stickers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProjectId = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NameAr = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NameCh = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NameRu = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project_Stickers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Project_Stickers_Projects_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Projects",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Project_Stickers_ProjectId",
                table: "Project_Stickers",
                column: "ProjectId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Project_Stickers");

            migrationBuilder.DropColumn(
                name: "NameAr",
                table: "Project_Payment_Plans");

            migrationBuilder.DropColumn(
                name: "NameCh",
                table: "Project_Payment_Plans");

            migrationBuilder.DropColumn(
                name: "NameRu",
                table: "Project_Payment_Plans");

            migrationBuilder.DropColumn(
                name: "TypeAr",
                table: "Project_Floor_Plans");

            migrationBuilder.DropColumn(
                name: "TypeCh",
                table: "Project_Floor_Plans");

            migrationBuilder.DropColumn(
                name: "TypeRu",
                table: "Project_Floor_Plans");

            migrationBuilder.AddColumn<string>(
                name: "AddressKz",
                table: "Properties",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionKz",
                table: "Properties",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NameKz",
                table: "Properties",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AddressKz",
                table: "Projects",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionKz",
                table: "Projects",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NameKz",
                table: "Projects",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionKz",
                table: "Employees",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NameKz",
                table: "Amenities",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);
        }
    }
}
