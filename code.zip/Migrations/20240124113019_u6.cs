﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApi.Migrations
{
    /// <inheritdoc />
    public partial class u6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AboutLocation",
                table: "Projects",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AboutLocationAr",
                table: "Projects",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AboutLocationCh",
                table: "Projects",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AboutLocationRu",
                table: "Projects",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleAr",
                table: "Articles",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleCh",
                table: "Articles",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleRu",
                table: "Articles",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionAr",
                table: "Article_Sections",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionCh",
                table: "Article_Sections",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DescriptionRu",
                table: "Article_Sections",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleAr",
                table: "Article_Sections",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleCh",
                table: "Article_Sections",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TitleRu",
                table: "Article_Sections",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AboutLocation",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "AboutLocationAr",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "AboutLocationCh",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "AboutLocationRu",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "TitleAr",
                table: "Articles");

            migrationBuilder.DropColumn(
                name: "TitleCh",
                table: "Articles");

            migrationBuilder.DropColumn(
                name: "TitleRu",
                table: "Articles");

            migrationBuilder.DropColumn(
                name: "DescriptionAr",
                table: "Article_Sections");

            migrationBuilder.DropColumn(
                name: "DescriptionCh",
                table: "Article_Sections");

            migrationBuilder.DropColumn(
                name: "DescriptionRu",
                table: "Article_Sections");

            migrationBuilder.DropColumn(
                name: "TitleAr",
                table: "Article_Sections");

            migrationBuilder.DropColumn(
                name: "TitleCh",
                table: "Article_Sections");

            migrationBuilder.DropColumn(
                name: "TitleRu",
                table: "Article_Sections");
        }
    }
}
