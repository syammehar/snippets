﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Common;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    [Authorize]
    public class BookingsController : ApiControllerBase
    {

        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly PropertyService _propertyService;
        private readonly IValidator<CreateBookingVm> _validateBooking;


        public BookingsController(UnitOfWork uow,
            IValidator<CreateBookingVm> validateBooking,
            LoggedInUser user,
            PropertyService propertyService)
        {

            _uow = uow;
            _validateBooking = validateBooking;
            _user = user;
            _propertyService = propertyService;
        }
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Add(CreateBookingVm req)
        {
            _validateBooking.ValidateAndThrow(req);

            var property = await _uow.Properties.GetDetails(req.PropertyId);

            if (property is null)
            {
                throw new Exception($"Property with Id:{req.PropertyId} not found");
            }

            var curTime = DateTime.UtcNow;
            var booking = new Booking
            {
                CreatedDate = curTime,
                UpdatedDate = curTime,
                NoteToAgent = req.NoteToAgent,
                AgentId = property.AgentId,
                UserId = _user.UserId,
                PropertyId = property.Id,
                Date = req.Date,
                Contact = req.Contact,
                Email = req.Email,
                FullName = req.FullName,
                Gender = req.Gender,
            };
            booking = await _uow.Bookings.Add(booking);
            await _uow.CompleteAsync();
            return Ok(new { booking.Id, booking.CreatedDate, booking.AgentId, booking.Date });
        }

        [Authorize(Roles = Roles.Admin)]
        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] FilterBase filter)
        {
            var bookings = await _uow.Bookings.Filter(filter);
            return Ok(bookings);

        }
        [Authorize]
        [HttpGet("my")]
        public async Task<IActionResult> MyBookings([FromQuery] FilterBase filter)
        {
            var bookings = await _propertyService.GetUserBookingProperties(filter);
            return Ok(bookings);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> ById(int id)
        {
            var bookings = await _uow.Bookings.Find(id);
            return Ok(bookings);
        }
    }
}