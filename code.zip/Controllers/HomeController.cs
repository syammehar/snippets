﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using WebApi.Common;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    public class HomeController : ApiControllerBase
    {
        private readonly UnitOfWork _uow;
        private readonly PropertyService _propertyService;
        private readonly TestimonialService _testimonialService;
        private readonly HttpClient _client;
        private readonly IMemoryCache _cache;


        public HomeController(UnitOfWork uow,
            PropertyService propertyService,
            TestimonialService testimonialService,
            IHttpClientFactory clientFactory,
            IMemoryCache cache)
        {
            _uow = uow;
            _propertyService = propertyService;
            _testimonialService = testimonialService;
            _client = clientFactory.CreateClient(AppConstants.ApiExchangeRateClientName);
            _cache = cache;
        }


        [HttpGet]
        public async Task<IActionResult> Index()
        {

            var offers = await _propertyService.Filter(new PropertyFilter { BestOffer = true });
            var rental = await _propertyService.Filter(new PropertyFilter { IsRental = true });
            var testimonail = await _testimonialService.Filter(new FilterBase { PageSize = 20 });

            return Ok(new
            {
                RentalProperties = rental.Data,
                FeaturedProperties = offers.Data,
                Agents = new { },
                Testimonials = testimonail.Data,
            });
        }

        [HttpGet("exchange-rates")]
        public async Task<IActionResult> ExchangeRates()
        {
            if (!_cache.TryGetValue("exchange-rates", out object? exchangeRates))
            {
                exchangeRates = await _client.GetFromJsonAsync<dynamic>("");
                _cache.Set("exchange-rates", exchangeRates, TimeSpan.FromMinutes(60));
            }
            return Ok(exchangeRates);
        }
    }
}
