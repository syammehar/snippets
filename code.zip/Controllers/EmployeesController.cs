﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using WebApi.Common;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    public class EmployeesController : ApiControllerBase
    {
        private readonly UnitOfWork _uow;
        private readonly EmployeeService _service;
        private readonly UploadService _upload;
        private readonly IValidator<EmployeeVm> _validateEmployee;

        public EmployeesController(UnitOfWork uow,
            UploadService upload,
            EmployeeService service,
            IValidator<EmployeeVm> validateEmployee)
        {
            _uow = uow;
            _upload = upload;
            _service = service;
            _validateEmployee = validateEmployee;
        }

        [Authorize(Roles = Roles.Admin)]
        [HttpPost]
        public async Task<IActionResult> Save(EmployeeVm employee)
        {
            _validateEmployee.ValidateAndThrow(employee);

            var newEmp = await _service.Save(employee);
            return Ok(
                new
                {
                    newEmp.Id,
                    newEmp.FirstName,
                    newEmp.LastName,
                    newEmp.UpdatedDate
                });
        }


        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] EmployeeFilter filter)
        {
            var data = await _service.Filter(filter);
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetId(int id)
        {
            var data = await _service.GetDetails(id);
            return Ok(data);
        }

        [Authorize(Roles = Roles.Admin)]
        [HttpGet("{id}/change-status")]
        public async Task<IActionResult> ChangeStatus(int id, bool active = false)
        {
            var status = await _service.ChangeEmployeeStatus(id, active);
            return Ok(status);
        }
    }
}
