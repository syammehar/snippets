﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Common;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    public class ArticlesController : ApiControllerBase
    {
        private readonly ArticleService _service;
        private readonly IValidator<ArticleVm> _validateArticle;
        private readonly IValidator<ArticleSectionVm> _validateArtSection;

        public ArticlesController(
            IValidator<ArticleVm> validateArticle,
            ArticleService service,
            IValidator<ArticleSectionVm> validateArtSection)
        {
            _validateArticle = validateArticle;
            _service = service;
            _validateArtSection = validateArtSection;
        }

        [HttpGet("{slug}")]
        public async Task<IActionResult> Index(string slug)
        {
            var project = await _service.GetArtical(slug);

            return Ok(project);
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Save(ArticleVm article)
        {
            _validateArticle.ValidateAndThrow(article);
            var art = await _service.Save(article);
            return Ok(new {art.Id, art.UpdatedDate, art.Title });
        }

        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] ArticleFilter filter)
        {
            var data = await _service.Filter(filter);
            return Ok(data);
        }

        [Authorize]
        [HttpGet("{id}/change-status")]
        public async Task<IActionResult> ChangeStatus(int id, bool active = false)
        {
            var status = await _service.ChangeArticleStatus(id, active);
            return Ok(status);
        }
    }
}