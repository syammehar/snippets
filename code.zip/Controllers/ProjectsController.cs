﻿using FluentValidation;
using WebApi.Services;
using WebApi.ViewModels.Filters;
using WebApi.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace WebApi.Controllers
{
    public class ProjectsController : ApiControllerBase
    {
        private readonly ProjectService _service;
        private readonly IValidator<ProjectVm> _validator;
        public ProjectsController(
            ProjectService service,
            IValidator<ProjectVm> validator)
        {
            _service = service;
            _validator = validator;
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Save(ProjectVm project)
        {
            _validator.ValidateAndThrow(project);
            var newPro = await _service.Save(project);
            return Ok(new { newPro.Id, newPro.UpdatedDate, newPro.Name });
        }

        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] ProjectFilter filter)
        {
            //_validateFilter.ValidateAndThrow(filter);
            var data = await _service.Filter(filter);
            return Ok(data);
        }

        [HttpGet("{slug}")]
        public async Task<IActionResult> Index(string slug)
        {
            var project = await _service.GetProject(slug);

            return Ok(project);
        }

        [Authorize]
        [HttpGet("{id}/change-status")]
        public async Task<IActionResult> ChangeStatus(int id, bool active = false)
        {
            var project = await _service.ChangeProjectStatus(id, active);
            return Ok(project);
        }

        [Authorize]
        [HttpPost("{id}/floor-plan")]
        public async Task<IActionResult> Add(int id, IEnumerable<FloorPlanVm> floorPlan)
        {
            var result = await _service.SaveFloorPlan(id, floorPlan);
            return Ok(new { result.Id, });
        }

        [HttpGet("{id}/floor-plan")]
        public async Task<IActionResult> FlorPlan(int id)
        {
            var result = await _service.GetFloorPlan(id);
            return Ok(result);
        }
    }
}
