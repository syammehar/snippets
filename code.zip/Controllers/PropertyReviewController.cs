﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    public class PropertyReviewController : ApiControllerBase
    {
        private readonly ReviewsService _service;

        public PropertyReviewController(
            ReviewsService service)
        {
            _service = service;
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Add(PropertyReview review)
        {
            var result = await _service.Save(review);
            return Ok(new { result.Id });
        }

        [HttpGet("{propId}")]
        public async Task<IActionResult> ByProperty(int propId)
        {
            var result = await _service.GetByProperty(propId);
            return Ok(result);
        }
    }
}