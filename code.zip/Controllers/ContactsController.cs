﻿using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Persistence;
using WebApi.Services.Common;
using WebApi.Services;
using WebApi.ViewModels.Filters;
using WebApi.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using FluentValidation.AspNetCore;
using WebApi.Validations;
using WebApi.Common;

namespace WebApi.Controllers
{
    public class ContactsController : ApiControllerBase
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly ContactService _service;
        private readonly UploadService _upload;
        private readonly TokenService _tokenGen;
        //private readonly IServiceProvider _provider;
        private readonly IValidator<ContactVm> _validateContact;
        private readonly IValidator<FilterBase> _validateFilter;

        public ContactsController(UnitOfWork uow,
            LoggedInUser user,
            ContactService service,
            UploadService upload,
            TokenService tokenGen,
            IValidator<FilterBase> validateFilter,
            IValidator<ContactVm> validateContact)
        {
            _uow = uow;
            _user = user;
            _service = service;
            _upload = upload;
            _tokenGen = tokenGen;
            _validateFilter = validateFilter;
            _validateContact = validateContact;
        }

        [HttpPost]
        public async Task<IActionResult> Save(ContactVm contact)
        {
            _validateContact.ValidateAndThrow(contact);
            var data = await _service.Save(contact);
            return Ok
                (new
                {
                    data.Id,
                    data.Name,
                    data.Email,
                    data.Phone,
                    data.Message,
                    data.PropertyId,
                    data.ProjectId,
                    data.ItemName,
                    data.CreatedDate,
                });
        }
        [HttpPost("subscription")]
        public async Task<IActionResult> SaveSubscription(ContactVm contact)
        {
            if (string.IsNullOrWhiteSpace(contact.Email))
            {
                return BadRequest("Email is required.");
            }
            contact.ContactType = AppConstants.ContactTypeSubscription;
            var data = await _service.Save(contact);
            return Ok
                (new
                {
                    data.Id,
                    data.Email,
                    data.ContactType,
                    data.CreatedDate
                });
        }


        [Authorize(Roles = Roles.Admin)]
        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] FilterBase filter)
        {
            _validateFilter.ValidateAndThrow(filter);
            var data = await _service.Filter(filter);
            return Ok(data);

        }

        [Authorize(Roles = Roles.Admin)]
        [HttpGet("{id}/change-status")]
        public async Task<IActionResult> ChangeStatusContact(int id, bool active = false)
        {
            var status = await _service.ChangeStatus(id, active);
            return Ok(status);
        }

    }
}
