﻿using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json.Linq;
using WebApi.Common;
using WebApi.Common.Models;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.Persistence;
using WebApi.Services;
using WebApi.Services.Common;
using WebApi.ViewModels;
using WebApi.ViewModels.Filters;

namespace WebApi.Controllers
{
    public class PropertiesController : ApiControllerBase
    {
        private readonly UnitOfWork _uow;
        private readonly LoggedInUser _user;
        private readonly PropertyService _service;
        private readonly UploadService _upload;
        private readonly TokenService _tokenGen;
        private readonly IValidator<PropertyVm> _validateProperty;
        private readonly IValidator<FilterBase> _validateFilter;

        public PropertiesController(UnitOfWork uow,
            IValidator<PropertyVm> validateProperty,
            IValidator<FilterBase> validateFilter,
            LoggedInUser user,
            PropertyService service,
            TokenService tokenGen,
            UploadService upload)
        {
            _uow = uow;
            _validateProperty = validateProperty;
            _validateFilter = validateFilter;
            _user = user;
            _service = service;
            _tokenGen = tokenGen;
            _upload = upload;
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Save(PropertyVm property)
        {
            _validateProperty.ValidateAndThrow(property);

            var propNew = await _service.Save(property);
            return Ok(new { propNew.Id, propNew.UpdatedDate, propNew.Name });
        }

        [HttpGet]
        public async Task<IActionResult> Filter([FromQuery] PropertyFilter filter)
        {
            _validateFilter.ValidateAndThrow(filter);
            var data = await _service.Filter(filter);
            return Ok(data);
        }
        [HttpGet("my")]
        public async Task<IActionResult> FilterMyProperties([FromQuery] PropertyFilter filter)
        {
            _validateFilter.ValidateAndThrow(filter);
            var data = await _service.Filter(filter, _user.UserId);
            return Ok(data);
        }


        [HttpGet("{slug}")]
        public async Task<IActionResult> Index(string slug)
        {
            var property = await _service.GetProperty(slug);

            return Ok(property);
        }

        [Authorize]
        [HttpGet("{propId}/change-status")]
        public async Task<IActionResult> ChangeStatus(int propId, bool active = false)
        {
            var property = await _service.ChangeUserPropertyStatus(propId, active);
            return Ok(property);
        }

        //[Authorize(Roles = Roles.Admin)]
        [HttpPost("category")]
        public async Task<IActionResult> Add([FromBody] CategoryModel category)
        {
            category = await _uow.PropertyCategories.Add(category);
            await _uow.CompleteAsync();
            return Ok(new { category.Name, category.Id });
        }


        [HttpGet("categories")]
        public async Task<IActionResult> AllCategories()
        {
            var categories = await _uow.PropertyCategories.FindPaged(x => true, 0);
            return Ok(categories.Select(x =>
            {
                x.IconPath = _upload.GetResourceFullPath(x.IconPath);
                return x;
            }));
        }
        [HttpGet("count")]
        public async Task<IActionResult> Count()
        {
            var rental = await _uow.Properties.Count(x => x.Active && x.IsRental);
            var buy = await _uow.Properties.Count(x => x.Active && !x.IsRental);
            return Ok(new { rental, buy });
        }

        [HttpGet("masterdata")]
        public async Task<IActionResult> MasterData()
        {
            var masterdata = await _service.GetMasterData();
            return Ok(masterdata);
        }

        [HttpGet("masterdata/areas/{cityId}")]
        public async Task<IActionResult> MasterDataAreas(int cityId)
        {
            var areas = await _uow.PropertyAreas.Find(x => x.CityId == cityId);
            return Ok(areas);
        }


        [Authorize]
        [HttpGet("favorites")]
        public async Task<IActionResult> Favorite()
        {
            var data = await _service.GetUserFavoriteProperties();
            return Ok(data);
        }


        [Authorize]
        [HttpPost("favorite/{propId}")]
        public async Task<IActionResult> AddFavorite(int propId)
        {
            var curTime = DateTime.UtcNow;
            var fav = new PropertyFavorite
            {
                CreatedDate = curTime,
                Active = true,
                PropertyId = propId,
                UserId = _user.UserId
            };
            fav = await _uow.PropertyFavorites.Add(fav);
            await _uow.CompleteAsync();
            return Ok(new { fav.CreatedDate, fav.UserId, fav.Id, fav.PropertyId });
        }


        [Authorize]
        [HttpGet("favorite/{propId}")]
        public async Task<IActionResult> DeleteFavorite(int propId)
        {
            var favs = (await _uow.PropertyFavorites.Find(x => x.PropertyId == propId && x.UserId == _user.UserId)).ToList();
            if (favs.Count < 1)
            {
                return NotFound();
            }

            favs.ForEach(x => x.Active = false);

            await _uow.CompleteAsync();
            return NoContent();
        }
    }
}
