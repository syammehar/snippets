﻿using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.Persistence.Repository;

namespace WebApi.Persistence
{
    public class UnitOfWork : IDisposable
    {
        private readonly AppDbContext _context;

        public PropertyRepository Properties { get; private set; }
        public PropertyReviewRepository PropertyReviews { get; private set; }
        public BookingRepository Bookings { get; private set; }
        public CategoryRepository PropertyCategories { get; private set; }
        public PropertyCityRepository PropertyCities { get; private set; }
        public PropertyAreaRepository PropertyAreas { get; private set; }
        public ArticleRepository Articles { get; private set; }
        public UserRepository Users { get; private set; }
        public PropertyFavoriteRepository PropertyFavorites { get; private set; }
        public TestimonialRepository Testimonials { get; private set; }
        public ContactRepository Contacts { get; private set; }
        public EmployeeRepository Employees { get; private set; }
        public ProjectRepository Projects { get; private set; }
        public ProjectFloorPlanRepository ProjectFloorPlans { get; private set; }

        public UnitOfWork(AppDbContext context, ILoggerFactory loggerFactory)
        {
            _context = context;
            var logger = loggerFactory.CreateLogger("uow logs");
            Properties = new PropertyRepository(context, logger);
            Bookings = new BookingRepository(context, logger);
            PropertyCategories = new CategoryRepository(context, logger);
            PropertyCities = new PropertyCityRepository(context, logger);
            PropertyAreas = new PropertyAreaRepository(context, logger);
            PropertyReviews = new PropertyReviewRepository(context, logger);
            Articles = new ArticleRepository(context, logger);
            Users = new UserRepository(context, logger);
            PropertyFavorites = new PropertyFavoriteRepository(context, logger);
            Testimonials = new TestimonialRepository(context, logger);
            Contacts = new ContactRepository(context, logger);
            Employees = new EmployeeRepository(context, logger);
            Projects = new ProjectRepository(context, logger);
            ProjectFloorPlans = new ProjectFloorPlanRepository(context, logger);
        }

        public Task CompleteAsync()
        {
            return _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }


    }
}
