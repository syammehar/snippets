﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.ViewModels.Filters;
using WebApi.Services;
using WebApi.Common.Models;
using System.Diagnostics.Metrics;

namespace WebApi.Persistence.Repository
{
    public class PropertyRepository : GenericRepository<Property>
    {

        public PropertyRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<IEnumerable<int>> AllRooms()
        {
            return await dbSet
                .Where(x => !x.IsStudio)
                .Select(x => x.Bedroom)
                .Distinct()
                .ToListAsync();
        }

        internal async Task<DataPageModel<Property>> Filter(PropertyFilter filter, int? agentId)
        {
            var page = new DataPageModel<Property>();
            var query = dbSet
                .Include(x => x.Images.Where(x => !x.Deleted))
                .Include(x => x.Category)
                .Include(x => x.City)
                .Include(x => x.Area)
                .Include(x => x.User)
                .Include(x => x.Amenities)
                .ThenInclude(x => x.Amenity)
                .Where(x => filter.IncludeInActive || x.Active);
            query = BuildFilterQuery(filter, agentId, query);
            page.Count = await query.CountAsync();
            if (page.Count > 0)
            {
                var pageCount = (float)page.Count / filter.PageSize;
                page.PageCount = Math.Ceiling(pageCount);
                var offSet = filter.PageSize * filter.Page;
                page.Data = await query
                    .Skip(offSet)
                    .Take(filter.PageSize)
                    .ToListAsync();
            }

            return page;
        }

        internal Task<Property?> GetDetails(int id)
        {
            var query = dbSet
                .Include(x => x.Images.Where(x => !x.Deleted))
                .Include(x => x.Area)
                .Include(x => x.City)
                .Include(x => x.Category)
                .Include(x => x.User)
                .Include(x => x.Amenities)
                .ThenInclude(x => x.Amenity);

            return query.FirstOrDefaultAsync(x => x.Id == id);
        }

        private static IQueryable<Property> BuildFilterQuery(PropertyFilter filter, int? agentId, IQueryable<Property> query)
        {

            var parameterExpr = Expression.Parameter(typeof(Property), "p");

            var expressionList = new List<Expression>();

            if (filter.Random)
            {
                query = query.OrderBy(x => Guid.NewGuid());
            }

            if (agentId.HasValue)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.AgentId));
                var val = Expression.Constant(agentId);
                var cond = Expression.Equal(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MaxPrice.HasValue && filter.MaxPrice > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Price));
                var val = Expression.Constant(filter.MaxPrice.Value);
                var cond = Expression.LessThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MinPrice.HasValue && filter.MinPrice > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Price));
                var val = Expression.Constant(filter.MinPrice.Value);
                var cond = Expression.GreaterThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MaxArea.HasValue && filter.MaxArea > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Size));
                var val = Expression.Constant(filter.MaxArea.Value, typeof(decimal?));
                var cond = Expression.LessThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MinArea.HasValue && filter.MinArea > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Size));
                var val = Expression.Constant(filter.MinArea.Value, typeof(decimal?));
                var cond = Expression.GreaterThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MaxBeds.HasValue && filter.MaxBeds > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Bedroom));
                var val = Expression.Constant(filter.MaxBeds.Value);
                var cond = Expression.LessThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MinBeds.HasValue && filter.MinBeds > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.Bedroom));
                var val = Expression.Constant(filter.MinBeds.Value);
                var cond = Expression.GreaterThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.CategoryId.HasValue && filter.CategoryId > 0)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.CategoryId));
                var val = Expression.Constant(filter.CategoryId.Value);
                var cond = Expression.Equal(prop, val);
                expressionList.Add(cond);
            }


            if (filter.IsRental.HasValue)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.IsRental));
                var val = Expression.Constant(filter.IsRental.Value);
                var cond = Expression.Equal(prop, val);
                expressionList.Add(cond);
            }

            if (filter.BestOffer.HasValue)
            {
                var prop = Expression.Property(parameterExpr, nameof(Property.BestOffer));
                var val = Expression.Constant(filter.BestOffer.Value);
                var cond = Expression.Equal(prop, val);
                expressionList.Add(cond);
            }

            if (!string.IsNullOrEmpty(filter.Search))
            {
                var searchValue = Expression.Constant(filter.Search);
                var searchMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });

                var searchConditions = new List<Expression>
                {
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.Name)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.NameAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.NameRu)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.NameCh)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.Address)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.AddressAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.AddressRu)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(parameterExpr, nameof(Property.AddressCh)), searchMethod, searchValue),
                };

                var searchCondition = searchConditions.Aggregate(Expression.Or);
                expressionList.Add(searchCondition);
            }
            if (expressionList.Count > 0)
            {
                var andExpression = expressionList.Aggregate(Expression.AndAlso);
                var lambda = Expression.Lambda<Func<Property, bool>>(andExpression, parameterExpr);
                query = query.Where(lambda);
            }


            if (!string.IsNullOrEmpty(filter.OrderBy))
            {
                //var selector = Expression.PropertyOrField(parameterExpr, filter.OrderBy);
                //var method = filter.Desc ? "OrderByDescending" : "OrderBy";
                //expression = Expression.Call(typeof(Queryable), method,
                //    new Type[] { source.ElementType, selector.Type },
                //    expression, Expression.Quote(Expression.Lambda(selector, parameterExpr)));

                query = filter.Desc ?
                query.OrderByDescending(x => EF.Property<Property>(x, filter.OrderBy)) :
                query.OrderBy(x => EF.Property<Property>(x, filter.OrderBy));
            }

            return query;
        }

        internal async Task<IEnumerable<Amenity>> AllAmenities()
        {
            return await _context.Amenities.ToListAsync();
        }
    }
}

/*
        internal Task<IEnumerable<Property>> FilterUsingSql(PropertyFilter filter)
        {
            var whereItems = new List<string>();
            var paramsList = new List<SqlParameter>();

            if (filter.MaxPrice.HasValue)
            {
                paramsList.Add(new SqlParameter("@" + nameof(filter.MaxPrice), filter.MaxPrice));
                whereItems.Add($"{nameof(Property.Price)} <= @{nameof(filter.MaxPrice)}");
            }
            if (filter.MinPrice.HasValue)
            {
                paramsList.Add(new SqlParameter("@" + nameof(filter.MinPrice), filter.MinPrice));
                whereItems.Add($"{nameof(Property.Price)} >= @{nameof(filter.MinPrice)}");
            }
            if (filter.CategoryId.HasValue)
            {
                paramsList.Add(new SqlParameter("@" + nameof(filter.CategoryId), filter.CategoryId));
                whereItems.Add($"{nameof(Property.CategoryId)} = @{nameof(filter.CategoryId)}");
            }

            var whereClause = whereItems.Count > 0 ? "WHERE " + string.Join(" AND ", whereItems) : "";

            var orderByClause = GetPaginationAndOrderByClause(filter);

            var query = $@"SELECT * FROM Properties
{whereClause}
{orderByClause}";
            //dbSet.sql omSqlInterpolated(new FormattableString())
            return ExecuteRawSql(paramsList, query);
        }*/
