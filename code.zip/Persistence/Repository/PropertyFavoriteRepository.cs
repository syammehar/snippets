﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class PropertyFavoriteRepository : GenericRepository<PropertyFavorite>
    {
        public PropertyFavoriteRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<IEnumerable<PropertyFavorite>> GetUserFavorites(int userId)
        {
            return await dbSet
                .OrderByDescending(x=>x.Id)
                .Where(x=>x.Active)
                .Take(100)
                .Where(x => x.UserId == userId)
                .Include(x => x.Property)
                .ToListAsync();
        }
    }
}
