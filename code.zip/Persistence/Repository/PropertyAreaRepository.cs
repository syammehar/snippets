﻿using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class PropertyAreaRepository : GenericRepository<AreaModel>
    {
        public PropertyAreaRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }
    }
}
