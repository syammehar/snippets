﻿using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class FileRepository : GenericRepository<FileModel>
    {
        public FileRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        { 
        }
    }
    public static class ExtensionMethods
    {
        public static void MarkAsDeleted(this ICollection<FileModel> entities)
        {
            entities.ToList().ForEach(x => { x.Deleted = true; });
        }
    }
}
