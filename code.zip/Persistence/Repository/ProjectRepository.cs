﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using WebApi.Common.Models;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.ViewModels.Filters;

namespace WebApi.Persistence.Repository
{
    public class ProjectRepository : GenericRepository<Project>
    {
        public ProjectRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }


        internal Task<Project?> GetDetails(int id)
        {
            var query = dbSet
                .Include(x => x.Images.Where(x => !x.Deleted))
                .Include(x => x.Area)
                .Include(x => x.City)
                .Include(x => x.FloorPlan)
                .Include(x => x.PaymentPlan)
                .Include(x => x.Categories)
                .ThenInclude(x => x.Category)
                .Include(x => x.Amenities)
                .ThenInclude(x => x.Amenity)
                .Include(x=>x.Stickers2)
                .Where(x => x.Active);

            return query.FirstOrDefaultAsync(x => x.Id == id);
        }

        internal async Task<DataPageModel<Project>> Filter(ProjectFilter filter)
        {
            var page = new DataPageModel<Project>();
            var query = dbSet
                .Include(x => x.Images.Where(x => !x.Deleted))
                .Include(x => x.Categories)
                .ThenInclude(x => x.Category)
                .Include(x => x.City)
                .Include(x => x.Area)
                .Include(x => x.Stickers2)
                .Where(x => filter.IncludeInActive || x.Active);
            query = BuildFilterQuery(filter, query);
            page.Count = await query.CountAsync();
            if (page.Count > 0)
            {
                var pageCount = (float)page.Count / filter.PageSize;
                page.PageCount = Math.Ceiling(pageCount);
                var offSet = filter.PageSize * filter.Page;
                page.Data = await query
                    .Skip(offSet)
                    .Take(filter.PageSize)
                    .ToListAsync();
            }

            return page;
        }

        private static IQueryable<Project> BuildFilterQuery(ProjectFilter filter, IQueryable<Project> query)
        {

            var paramExprProject = Expression.Parameter(typeof(Project), "p");
            //var paramExprProjCat = Expression.Parameter(typeof(ProjectCategory), "pc");

            var expressionList = new List<Expression>();

            if (filter.Random)
            {
                query = query.OrderBy(x => Guid.NewGuid());
            }

            if (filter.MaxPrice.HasValue && filter.MaxPrice > 0)
            {
                var prop = Expression.Property(paramExprProject, nameof(Project.StartingPrice));
                var val = Expression.Constant(filter.MaxPrice.Value);
                var cond = Expression.LessThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MinPrice.HasValue && filter.MinPrice > 0)
            {
                var prop = Expression.Property(paramExprProject, nameof(Project.StartingPrice));
                var val = Expression.Constant(filter.MinPrice.Value);
                var cond = Expression.GreaterThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MaxArea.HasValue && filter.MaxArea > 0)
            {
                var prop = Expression.Property(paramExprProject, nameof(Project.Size));
                var val = Expression.Constant(filter.MaxArea.Value);
                var cond = Expression.LessThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.MinArea.HasValue && filter.MinArea > 0)
            {
                var prop = Expression.Property(paramExprProject, nameof(Project.Size));
                var val = Expression.Constant(filter.MinArea.Value);
                var cond = Expression.GreaterThanOrEqual(prop, val);
                expressionList.Add(cond);
            }

            if (filter.CategoryId.HasValue && filter.CategoryId > 0)
            {
                //var prop = Expression.Property(Expression.Property(paramExprProject, nameof(Project.Categories)), nameof(CategoryModel.Id));
                //var val = Expression.Constant(filter.CategoryId.Value);
                //var cond = Expression.Equal(prop, val);
                //expressionList.Add(cond);

                //var prop = Expression.Property(paramExprProjCat, nameof(ProjectCategory.CategoryId));
                //var val = Expression.Constant(filter.CategoryId.Value);
                //var cond = Expression.Equal(prop, val);
                //expressionList.Add(cond);
            }
            if (filter.CityId.HasValue && filter.CityId > 0)
            {
                var prop = Expression.Property(paramExprProject, nameof(Project.CityId));
                var val = Expression.Constant(filter.CityId.Value);
                var cond = Expression.Equal(prop, val);
                expressionList.Add(cond);
            }


            if (!string.IsNullOrEmpty(filter.Search))
            {
                var searchValue = Expression.Constant(filter.Search);
                var searchMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });

                var searchConditions = new List<Expression>
                {
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.Name)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.NameAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.NameRu)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.NameCh)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.Address)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AddressAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AddressRu)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AddressCh)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.Description)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.DescriptionAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.DescriptionRu)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.DescriptionCh)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AboutLocation)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AboutLocationAr)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AboutLocationCh)), searchMethod, searchValue),
                    Expression.Call(Expression.Property(paramExprProject, nameof(Project.AboutLocationRu)), searchMethod, searchValue),
                };

                var searchCondition = searchConditions.Aggregate(Expression.Or);
                expressionList.Add(searchCondition);
            }
            if (expressionList.Count > 0)
            {
                var andExpression = expressionList.Aggregate(Expression.AndAlso);
                var lambda = Expression.Lambda<Func<Project, bool>>(andExpression, paramExprProject);
                query = query.Where(lambda);
            }
            if (filter.CategoryId.HasValue && filter.CategoryId > 0)
            {
                query = query.Where(p => p.Categories.Any(c => c.CategoryId == filter.CategoryId));
            }


            if (!string.IsNullOrEmpty(filter.OrderBy))
            {
                query = filter.Desc ?
                query.OrderByDescending(x => EF.Property<Project>(x, filter.OrderBy)) :
                query.OrderBy(x => EF.Property<Project>(x, filter.OrderBy));
            }

            return query;
        }
    }
}
