﻿using Microsoft.EntityFrameworkCore;
using WebApi.Common.Models;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.ViewModels.Filters;

namespace WebApi.Persistence.Repository
{
    public class BookingRepository : GenericRepository<Booking>
    {
        public BookingRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<DataPageModel<Booking>> Filter(FilterBase filter, int? userId = null, bool includeProperty = false)
        {
            var page = new DataPageModel<Booking>();
            var query = dbSet.AsQueryable();
            if (userId.HasValue)
            {
                query = query.Where(x => x.UserId == userId);
            }
            if (includeProperty)
            {
                query = query.Include(x => x.Property);
            }
            page.Count = await query.CountAsync();
            if (page.Count > 0)
            {
                var pageCount = (float)page.Count / filter.PageSize;
                page.PageCount = Math.Ceiling(pageCount);
                var offSet = filter.PageSize * filter.Page;
                page.Data = await query
                    .Skip(offSet)
                    .Take(filter.PageSize)
                    .ToListAsync();
            }

            return page;
        }
    }
}
