﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class PropertyReviewRepository : GenericRepository<PropertyReview>
    {

        public PropertyReviewRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<IEnumerable<PropertyReview>> ByPropertyId(int propId)
        {
            return await dbSet.Include(x=>x.User)
                .Where(x => x.PropertyId == propId)
                .OrderByDescending(x=>x.Id)
                .Take(500)
                .ToListAsync();
        }


    }
}
