﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class PropertyAmenityRepository : GenericRepository<PropertyAmenity>
    {
        public PropertyAmenityRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal Task<PropertyAmenity?> GetDetails(int id)
        {
            var query = dbSet.AsQueryable();

            return query.FirstOrDefaultAsync(x => true);
        }
    }
}
