﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class ArticleSectionRepository : GenericRepository<ArticleSection>
    {
        public ArticleSectionRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<IEnumerable<ArticleSection>> ByArticleId(int artId)
        {
            return await dbSet
                .Where(x => x.ArticleId == artId)
                .OrderByDescending(x => x.Id)
                .ToListAsync();
        }

        internal Task RemoveByArticleId(int artId)
        {
            var toRemove = dbSet.Where(x => x.ArticleId == artId);
            dbSet.RemoveRange(toRemove);
            return Task.CompletedTask;
        }

    }
}
