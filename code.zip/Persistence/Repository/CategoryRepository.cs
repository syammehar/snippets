﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class CategoryRepository : GenericRepository<CategoryModel>
    {
        public CategoryRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }
    }
}
