﻿using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class PropertyCityRepository : GenericRepository<CityModel>
    {
        public PropertyCityRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }
    }
}
