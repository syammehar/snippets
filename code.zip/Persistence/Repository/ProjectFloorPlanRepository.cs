﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;
using WebApi.Models.Entities;

namespace WebApi.Persistence.Repository
{
    public class ProjectFloorPlanRepository : GenericRepository<ProjectFloorPlan>
    {
        public ProjectFloorPlanRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        { 
        }


        internal async Task<IEnumerable<ProjectFloorPlan>> ByProjectId(int projectId)
        {
            return await dbSet
                .Where(x => x.ProjectId == projectId)
                .OrderByDescending(x => x.Id)
                .ToListAsync();
        }
        internal Task RemoveByProjectId(int projectId)
        {
            var toRemove = dbSet.Where(x => x.ProjectId == projectId);
            dbSet.RemoveRange(toRemove);
            return Task.CompletedTask;
        }

        //internal Task<ProjectFloorPlan?> GetDetails(int id)
        //{
        //    var query = dbSet..AsQueryable();
               

        //    return query.FirstOrDefaultAsync(x => x.Id == id);
        //}
    }
}
