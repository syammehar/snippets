﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using WebApi.Common.Models;
using WebApi.Models;
using WebApi.Models.Entities;
using WebApi.ViewModels.Filters;

namespace WebApi.Persistence.Repository
{
    public class ContactRepository : GenericRepository<Contact>
    {
        public ContactRepository(AppDbContext _context, ILogger logger) : base(_context, logger)
        {
        }

        internal async Task<DataPageModel<Contact>> Filter(FilterBase filter)
        {
            var page = new DataPageModel<Contact>();
            var query = dbSet.AsQueryable().Where(x=>x.Active);
            query = BuildFilterQuery(filter, query);
            page.Count = await query.CountAsync();
            if (page.Count > 0)
            {
                var pageCount = (float)page.Count / filter.PageSize;
                page.PageCount = Math.Ceiling(pageCount);
                var offSet = filter.PageSize * filter.Page;
                page.Data = await query
                    .Skip(offSet)
                    .Take(filter.PageSize)
                    .ToListAsync();
            }
            return page;
        }
        private static IQueryable<Contact> BuildFilterQuery(FilterBase filter, IQueryable<Contact> query)
        {
            if (!string.IsNullOrEmpty(filter.OrderBy))
            {
                query = filter.Desc ?
                query.OrderByDescending(x => EF.Property<Contact>(x, filter.OrderBy)) :
                query.OrderBy(x => EF.Property<Contact>(x, filter.OrderBy));
            }

            return query;
        }
    }
}