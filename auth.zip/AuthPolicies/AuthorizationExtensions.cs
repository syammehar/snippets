﻿using Microsoft.AspNetCore.Authorization;
using Web.AuthPolicies.Requirements;

namespace Web.AuthPolicies
{
    public static class AuthorizationExtensions
    {
        public static void AddAuthorizationHandlers(this IServiceCollection services)
        {
            services.AddSingleton<IAuthorizationHandler, OrganizationRequirementHandler>();
            services.AddSingleton<IAuthorizationHandler, VendorRequirementHandler>();
        }
    }
}
