﻿using Microsoft.AspNetCore.Authorization;
using Web.AuthPolicies.Requirements;
using Web.Common;

namespace Web.AuthPolicies
{
    public static class AuthorizationOptionsExtensions
    {
        public static void AddAppPolicies(this AuthorizationOptions options)
        {
            options.AddPolicy(Policies.OrganizationManager,
                policy =>
                {
                    policy.RequireRole(Roles.Manager);
                    policy.Requirements.Add(new OrganizationRequirement());
                });
            options.AddPolicy(Policies.DiscountVendorUser,
                policy =>
                {
                    policy.RequireRole(Roles.DiscountVendor);
                    policy.Requirements.Add(new VendorRequirement());
                });
            options.AddPolicy(Policies.OrganizationSupervisor,
                policy =>
                {
                    policy.RequireRole(Roles.Supervisor);
                    policy.Requirements.Add(new OrganizationRequirement());
                });

        }
    }
}
