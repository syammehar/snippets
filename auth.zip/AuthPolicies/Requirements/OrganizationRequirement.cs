﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Web.Common;

namespace Web.AuthPolicies.Requirements
{
    public class OrganizationRequirement  : IAuthorizationRequirement
    {
    }
    public class OrganizationRequirementHandler : AuthorizationHandler<OrganizationRequirement>
    {
        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context, OrganizationRequirement requirement)
        {
            if (context.Resource is HttpContext httpContext)
            {
                var orgid = httpContext.Request.RouteValues["orgId"]?.ToString();

                string claimValue = context.User.FindFirstValue(CustomClaims.OrganizationId);

                if (orgid == claimValue)
                {
                    context.Succeed(requirement);
                }
            }

            return Task.CompletedTask;
        }
    }
}
