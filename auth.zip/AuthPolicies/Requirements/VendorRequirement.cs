﻿
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Web.Common;

namespace Web.AuthPolicies.Requirements
{
    public class VendorRequirement : IAuthorizationRequirement
    {
    }
    public class VendorRequirementHandler : AuthorizationHandler<VendorRequirement>
    {
        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context, VendorRequirement requirement)
        {
            if (context.Resource is HttpContext httpContext)
            {
                var vendorId = httpContext.Request.RouteValues["vendorId"]?.ToString();

                var claimValue = context.User.FindFirstValue(CustomClaims.VendorId);

                if (vendorId == claimValue)
                {
                    context.Succeed(requirement);
                }
            }

            return Task.CompletedTask;
        }
    }
}
