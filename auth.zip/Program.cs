using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Text.Json.Serialization;
using Web.Common;
using Web.Models;
using Web.Persistence;
using Web.AuthPolicies;
using Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddCors();

//builder.Services.AddLogging();

builder.Logging.AddFile(builder.Configuration.GetSection("Logging"));

builder.Services.AddControllers().AddJsonOptions(opts =>
{
    opts.JsonSerializerOptions.NumberHandling = JsonNumberHandling.AllowReadingFromString;
    opts.JsonSerializerOptions.PropertyNamingPolicy = null;
});
builder.Services.AddControllersWithViews();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
               .AddJwtBearer(options =>
               {
                   options.TokenValidationParameters = new TokenValidationParameters
                   {
                       ValidateIssuer = true,
                       ValidateAudience = true,
                       ValidateLifetime = true,
                       ValidateIssuerSigningKey = true,
                       ValidIssuer = builder.Configuration["Jwt:ValidIssuer"],
                       ValidAudience = builder.Configuration["Jwt:ValidAudience"],
                       IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"]))
                   };
               });

builder.Services.AddAuthorization(options =>
{
    options.AddAppPolicies();
});

builder.Services.AddAuthorizationHandlers();


builder.Services.AddHttpContextAccessor();

builder.Services.AddDbContext<AppDbContext>();
builder.Services.AddScoped<UnitOfWork>();

builder.Services.AddScoped<LoggedInUser>();

builder.Services.AddSingleton<EmailService>();
builder.Services.AddSingleton<TokenService>();
builder.Services.AddSingleton<UploadService>();
builder.Services.AddSingleton<VcfGenerator>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}


app.UseFileServer(new FileServerOptions
{
    FileProvider = new PhysicalFileProvider(
                    Path.Combine(Directory.GetCurrentDirectory(), "content")),
    RequestPath = "/content",
    EnableDefaultFiles = true
});

//app.UseHttpsRedirection();
app.UseCors(options => options.AllowAnyOrigin().AllowAnyHeader());

app.UseMiddleware<ErrorHandlerMiddleware>();

app.UseStaticFiles();
app.UseRouting();


app.UseAuthentication();
//uses bearer token issued from AAD
app.UseAuthorization();

//app.UseEndpoints(endpoints =>
//{
//    endpoints.MapGet("/profile/{*path}", async context =>
//    {
//        await context.Response.SendFileAsync("content/profile/index.html");
//    });
//});


app.MapControllerRoute(
    name: "default",
    pattern: "{controller}/{action=Index}/{id?}");

app.MapFallbackToFile("index.html"); ;

app.Run();
